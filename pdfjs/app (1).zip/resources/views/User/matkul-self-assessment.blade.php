@extends('layout.user')
@section('content')

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Self Assessment</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Mata Kuliah</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title center" align="center">Mata Kuliah yang akan di Konversi</h5>

              {{-- Display Transcript --}}
              @if ($transkrip)
                  <div class="mb-4">
                      <h6>Uploaded Transcript:</h6>
                      @php
                          $fileExtension = pathinfo($transkrip->file, PATHINFO_EXTENSION);
                      @endphp
                      @if (in_array($fileExtension, ['pdf']))
                          <iframe src="{{ route('view-transkrip', ['filename' => $transkrip->file]) }}" width="100%" height="500px"></iframe>
                      @elseif (in_array($fileExtension, ['jpg', 'jpeg', 'png']))
                          <img src="{{ route('view-transkrip', ['filename' => $transkrip->file]) }}" alt="Transcript Image" class="img-fluid">
                      @else
                          <p>Unsupported file format for preview. File: {{ $transkrip->file }}</p>
                      @endif
                  </div>
              @else
                  <div class="alert alert-info" role="alert">
                      No transcript uploaded yet.
                  </div>
              @endif

              

              <h1>Self-Assessment</h1>

                @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                <form action="{{ route('store-matkul-self-assessment') }}" method="POST">
                    @csrf

                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Mata Kuliah</th>
                                <th>Tidak Pernah</th>
                                <th>Baik</th>
                                <th>Sangat Baik</th>
                                <th>View CPMK</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($matkuls as $matkul)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $matkul->nama_matkul }}</td>
                                    @php
                                        $existingAssessment = $existingAssessments->get($matkul->id);
                                        $selectedValue = $existingAssessment ? $existingAssessment->self_assessment_value : null;
                                    @endphp
                                    <td style="text-align: center;">
                                        <input type="radio" name="assessments[{{ $matkul->id }}][self_assessment_value]" value="Tidak Pernah" {{ $selectedValue === 'Tidak Pernah' ? 'checked' : '' }}>
                                    </td>
                                    <td style="text-align: center;">
                                        <input type="radio" name="assessments[{{ $matkul->id }}][self_assessment_value]" value="Baik" {{ $selectedValue === 'Baik' ? 'checked' : '' }}>
                                    </td>
                                    <td style="text-align: center;">
                                        <input type="radio" name="assessments[{{ $matkul->id }}][self_assessment_value]" value="Sangat Baik" {{ $selectedValue === 'Sangat Baik' ? 'checked' : '' }}>
                                        <input type="hidden" name="assessments[{{ $matkul->id }}][matkul_id]" value="{{ $matkul->id }}">
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-info btn-sm view-cpmk-btn" data-matkul-id="{{ $matkul->id }}" data-matkul-name="{{ $matkul->nama_matkul }}">View CPMK</button>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6">No matkuls found for your major.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>

                    <button type="submit" class="btn btn-primary">Save Self-Assessment</button>
                </form>

            </div>
          </div>
          
        </div>
      </div>
    </section>

    {{-- CPMK Modal --}}
    <div class="modal fade" id="cpmkModal" tabindex="-1" aria-labelledby="cpmkModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cpmkModalLabel">CPMK for <span id="matkulNameInModal"></span></h5>
                    <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    {{-- CPMK table will be loaded here by JavaScript --}}
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="50">No</th>
                                <th>CPMK</th>
                            </tr>
                        </thead>
                        <tbody id="cpmkTableBody">
                            {{-- CPMK rows will be added here --}}
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

</main><!-- End #main -->
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var cpmkModal = new bootstrap.Modal(document.getElementById('cpmkModal'));
        var matkulNameInModal = document.getElementById('matkulNameInModal');
        var cpmkTableBody = document.getElementById('cpmkTableBody');

        document.querySelectorAll('.view-cpmk-btn').forEach(button => {
            button.addEventListener('click', function () {
                const matkulId = this.getAttribute('data-matkul-id');
                const matkulName = this.getAttribute('data-matkul-name');

                matkulNameInModal.textContent = matkulName;
                cpmkTableBody.innerHTML = ''; // Clear previous table rows

                // Show loading message
                const loadingRow = document.createElement('tr');
                const loadingCell = document.createElement('td');
                loadingCell.setAttribute('colspan', '2');
                loadingCell.textContent = 'Loading CPMK...';
                loadingCell.style.textAlign = 'center';
                loadingRow.appendChild(loadingCell);
                cpmkTableBody.appendChild(loadingRow);

                // Fetch CPMK data
                fetch(`{{ url('/user/matkul') }}/${matkulId}/cpmk`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok ' + response.statusText);
                        }
                        return response.json();
                    })
                    .then(data => {
                        cpmkTableBody.innerHTML = ''; // Clear loading message
                        if (data.length > 0) {
                            data.forEach((cpmk, index) => {
                                const row = document.createElement('tr');
                                const noCell = document.createElement('td');
                                const cpmkCell = document.createElement('td');

                                noCell.textContent = index + 1;
                                cpmkCell.textContent = cpmk.penjelasan; // Assuming CPMK model has 'penjelasan'

                                row.appendChild(noCell);
                                row.appendChild(cpmkCell);
                                cpmkTableBody.appendChild(row);
                            });
                        } else {
                            const noCpmkRow = document.createElement('tr');
                            const noCpmkCell = document.createElement('td');
                            noCpmkCell.setAttribute('colspan', '2');
                            noCpmkCell.textContent = 'No CPMK found for this Matkul.';
                             noCpmkCell.style.textAlign = 'center';
                            noCpmkRow.appendChild(noCpmkCell);
                            cpmkTableBody.appendChild(noCpmkRow);
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching CPMK:', error);
                        cpmkTableBody.innerHTML = ''; // Clear loading message
                        const errorRow = document.createElement('tr');
                        const errorCell = document.createElement('td');
                         errorCell.setAttribute('colspan', '2');
                        errorCell.textContent = 'Error loading CPMK.';
                         errorCell.style.textAlign = 'center';
                        errorRow.appendChild(errorCell);
                        cpmkTableBody.appendChild(errorRow);
                    });

                cpmkModal.show();
            });
        });
    });
</script>
@endpush

