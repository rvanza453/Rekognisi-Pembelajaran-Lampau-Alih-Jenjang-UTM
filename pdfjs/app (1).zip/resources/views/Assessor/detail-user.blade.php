<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <title>Detail User</title>
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/bootstrap-icons.css') }}">
</head>
<body>
@extends('layout.assessor')
@section('content')
<main id="main" class="main">

  <div class="pagetitle">
    <h1>Data Calon Mahasiswa</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item active"><a href="/list-name-table">Ajuan Form</a></li>
        <li class="breadcrumb-item active"><a href="/detail-user">Data Calon Mahasiswa</a></li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <!-- Export Buttons -->
  <!-- Tombol Export Utama -->
  <!--<div class="d-flex justify-content-end">-->
  <!--  <div class="btn-group">-->
  <!--      <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">-->
  <!--          <i class="bi bi-file-word me-1"></i> Export-->
  <!--      </button>-->
  <!--      <ul class="dropdown-menu dropdown-menu-end">-->
  <!--          <li><a class="dropdown-item" href="{{ route('export-word02', $camaba->id) }}"><i class="bi bi-file-word me-1"></i> Export Word F02</a></li>-->
  <!--          <li><a class="dropdown-item" href="{{ route('exportPdfFromWordF02', $camaba->id) }}"><i class="bi bi-file-pdf me-1"></i> Export PDF V2</a></li>-->
  <!--          <li><a class="dropdown-item" href="{{ route('export-pdfF02', $camaba->id) }}"><i class="bi bi-file-pdf me-1"></i> Export PDF</a></li>-->
  <!--          <li><a class="dropdown-item" href="{{ route('export-word08', $camaba->id) }}"><i class="bi bi-file-word me-1"></i> Export Word F08</a></li>-->
  <!--          <li><a class="dropdown-item" href="{{ route('exportPdfFromWordF08', $camaba->id) }}"><i class="bi bi-file-pdf me-1"></i> Export PDF F08</a></li>-->
  <!--      </ul>-->
  <!--  </div>-->
  <!--</div>-->

  <div class="container-fluid mt-2">
    <div class="row">
        <div class="col-md-12">
            <ul class="nav nav-pills justify-content-center gap-2 mb-4 flex-wrap">
                <li class="nav-item">
                    <button class="nav-link active btn btn-primary btn-sm" onclick="showTab('profil')">
                        <i class="fas fa-user-circle me-1"></i> Profil
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link btn btn-outline-primary btn-sm" onclick="showTab('ijazah')">
                        <i class="fas fa-graduation-cap me-1"></i> Ijazah
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link btn btn-outline-primary btn-sm" onclick="showTab('bukti')">
                        <i class="fas fa-receipt me-1"></i> Bukti
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link btn btn-outline-primary btn-sm" onclick="showTab('transkrip')">
                        <i class="fas fa-book me-1"></i> Penilaian Konversi
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link btn btn-outline-primary btn-sm" onclick="showTab('penilaian-matkul')">
                        <i class="fas fa-star me-1"></i> Hasil Penilaian
                    </button>
                </li>
            </ul>
        </div>
    </div>
  </div>

  <!-- PROFIL -->
  <div class="tab-content active" id="profil">
    <h2>Data Diri Mahasiswa</h2>
    <div class="card">
      <div class="ijazah-overview-assessor mx-4 my-3">
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Nama</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->nama ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Prodi</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->jurusan->nama_jurusan ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Alamat</div>
          <div class="col-lg-9 col-md-8">{{   $camaba->alamat ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Email</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->user->email ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">No Wa</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->nomor_telepon ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Tempat Lahir</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->tempat_lahir ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Tanggal Lahir</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->tanggal_lahir ? \Carbon\Carbon::parse($camaba->tanggal_lahir)->format('d/m/Y') : '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Jenis Kelamin</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->kelamin ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Kota</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->kota ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Provinsi</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->provinsi ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Kode Pos</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->kode_pos ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Kebangsaan</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->kebangsaan ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Nomor Rumah</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->nomor_rumah ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Nomor Kantor</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->nomor_kantor ?? '-'  }}</div>
        </div>
      </div>
    </div>
  </div>

  <!-- IJAZAH -->
  <div class="tab-content" id="ijazah">
    <h2>Data Ijazah</h2>
    <div class="card">
      <div class="ijazah-overview-assessor mx-4 my-3">
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Institusi Pendidikan</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->ijazah->institusi_pendidikan ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Jenjang</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->ijazah->jenjang ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Provinsi</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->ijazah->provinsi ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Kota</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->ijazah->kota ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Negara</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->ijazah->negara ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Fakultas</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->ijazah->fakultas ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Jurusan</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->ijazah->jurusan ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Nilai/IPK</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->ijazah->ipk_nilai ?? '-'  }}</div>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 col-md-4 label">Tahun Lulus</div>
          <div class="col-lg-9 col-md-8">{{  $camaba->ijazah->tahun_lulus ?? '-'  }}</div>
        </div>
        <div class="row mb-2">
          <div class="col-lg-3 col-md-4 label">Bukti File</div>
          <div class="col-lg-9 col-md-8">
            @if($camaba->ijazah && $camaba->ijazah->file)
              <a href="{{ route('assessor.download-ijazah', $camaba->id) }}" class="btn btn-primary btn-sm">
                <i class="bi bi-download"></i> Download Ijazah
              </a>
            @else
              <span class="text-muted">File tidak tersedia</span>
            @endif
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- BUKTI -->
  <div class="tab-content" id="bukti">
    <h2>Bukti Alih Jenjang</h2>
    <div class="card">
      <div class="card-body mt-4">
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>No</th>
                <th>Jenis Dokumen</th>
                <th>Nama File</th>
                <th>Tanggal Upload</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              @forelse($camaba->bukti_alih_jenjang as $index => $bukti)
                <tr>
                  <td>{{ $index + 1 }}</td>
                  <td>{{ $bukti->jenis_dokumen }}</td>
                  <td>{{ $bukti->file }}</td>
                  <td>{{ $bukti->created_at->format('d/m/Y H:i') }}</td>
                  <td>
                    <a href="{{ route('assessor.view-bukti-alih-jenjang', ['filename' => $bukti->file]) }}" target="_blank" class="btn btn-sm btn-info">
                      <i class="bi bi-eye"></i> Lihat
                    </a>
                    <a href="{{ route('assessor.download-bukti-alih-jenjang', ['filename' => $bukti->file]) }}" class="btn btn-sm btn-primary">
                      <i class="bi bi-download"></i> Unduh
                    </a>
                  </td>
                </tr>
              @empty
                <tr>
                  <td colspan="5" class="text-center">Belum ada bukti yang diunggah</td>
                </tr>
              @endforelse
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <!-- TRANSKRIP -->
  <div class="tab-content" id="transkrip">
    <h2>Data Transkrip</h2>
    <div class="card">
      <div class="transkrip-overview-assessor mx-4 my-3">
        @if($camaba->transkrip)
          <div class="row mb-3">
            <div class="col-lg-3 col-md-4 label">File Transkrip</div>
            <div class="col-lg-9 col-md-8">{{ $camaba->transkrip->file }}</div>
          </div>
          <div class="row mb-3">
            <div class="col-lg-3 col-md-4 label">Tanggal Upload</div>
            <div class="col-lg-9 col-md-8">
              {{ $camaba->transkrip->created_at->format('d-m-Y H:i:s') }}
            </div>
          </div>
          @php
            $fileExtension = strtolower(pathinfo($camaba->transkrip->file, PATHINFO_EXTENSION));
          @endphp
          @if($fileExtension === 'pdf')
            <div class="pdf-container mt-3">
              <embed src="{{ route('assessor.view-transkrip', $camaba->transkrip->file) }}" type="application/pdf" width="100%" height="600px" />
            </div>
          @else
            <div class="mt-3">
              <img src="{{ route('assessor.view-transkrip', $camaba->transkrip->file) }}" alt="Transkrip" class="img-fluid">
            </div>
          @endif
        @else
          <div class="alert alert-info">
            Mahasiswa belum mengunggah transkrip
          </div>
        @endif
      </div>
    </div>

    <h2>Penilaian Self-Assessment Mata Kuliah</h2>
    <div class="card">
      <div class="card-body table-responsive mt-4">
        @if ($matkulAssessments->isEmpty())
          <div class="alert alert-info" role="alert">
            Mahasiswa belum melakukan self-assessment mata kuliah.
          </div>
        @else
          <form id="assessorAssessmentForm" action="{{ route('assessor.save-matkul-assessment') }}" method="POST" onsubmit="return validateForm()">
            @csrf
            <input type="hidden" name="calon_mahasiswa_id" value="{{ $camaba->id }}">
            <input type="hidden" name="assessor_id" value="{{ auth()->user()->assessor->id ?? '' }}">

            @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            @endif

            @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            @endif

            <table class="table table-bordered">
              <thead>
                <th rowspan="2" class="text-center" style="vertical-align: middle;">No</th>
                  <th rowspan="2" style="vertical-align: middle;" width="300">Nama Mata Kuliah</th>
                  <th rowspan="2" style="vertical-align: middle;">CPMK</th>
                  
                  <th colspan="3" class="text-center">Penilaian Anda</th> 
                  
                  <th rowspan="2" style="vertical-align: middle;" width="120">Self-Assessment Mahasiswa</th>
                  <th rowspan="2" style="vertical-align: middle;" width="200">Nilai Matkul</th>
                </tr>
            
                <tr>
                  <th class="text-center">Tidak Pernah</th>
                  <th class="text-center">Baik</th>
                  <th class="text-center">Sangat Baik</th>
                </tr>
              </thead>
              <tbody>
                @foreach ($matkulAssessments as $assessment)
                @php
                    // Ambil MatkulScore yang sesuai untuk matkul ini dari koleksi $matkulScores
                    $currentMatkulScore = $matkulScores[$assessment->matkul_id] ?? null;
        
                    // Ambil data status (isComplete, isLolos) dari koleksi $matkul (yang berisi matkulWithStatus)
                    $currentMk = $matkul->firstWhere('id', $assessment->matkul_id);
                @endphp
                  <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $assessment->matkul->nama_matkul ?? '-' }}</td>
                    <td>
                       <button type="button" class="btn btn-info btn-sm view-cpmk-btn"
                               data-matkul-id="{{ $assessment->matkul_id }}"
                               data-matkul-name="{{ $assessment->matkul->nama_matkul ?? '-' }}">
                         View CPMK
                       </button>
                    </td>
                    @php
                        $assessorId = auth()->user()->assessor->id ?? null;
                        $assessorAssessment = null;

                        if ($assessorId) {
                            if ($assessment->assessor1_id == $assessorId) {
                                $assessorAssessment = $assessment->assessor1_assessment;
                            } elseif ($assessment->assessor2_id == $assessorId) {
                                $assessorAssessment = $assessment->assessor2_assessment;
                            } elseif ($assessment->assessor3_id == $assessorId) {
                                $assessorAssessment = $assessment->assessor3_assessment;
                            }
                        }
                        $displayAssessorValue = $assessorAssessment ?? 'Belum dinilai';
                    @endphp
                    <td class="text-center">
                        <div class="form-check">
                            <input type="radio" name="assessments[{{ $assessment->id }}][value]" value="Tidak Pernah" {{ $assessorAssessment === 'Tidak Pernah' ? 'checked' : '' }} class="form-check-input">
                        </div>
                    </td>
                    <td class="text-center">
                        <div class="form-check">
                            <input type="radio" name="assessments[{{ $assessment->id }}][value]" value="Baik" {{ $assessorAssessment === 'Baik' ? 'checked' : '' }} class="form-check-input">
                        </div>
                    </td>
                    <td class="text-center">
                        <div class="form-check">
                            <input type="radio" name="assessments[{{ $assessment->id }}][value]" value="Sangat Baik" {{ $assessorAssessment === 'Sangat Baik' ? 'checked' : '' }} class="form-check-input">
                        </div>
                        <input type="hidden" name="assessments[{{ $assessment->id }}][matkul_assessment_id]" value="{{ $assessment->id }}">
                    </td>
                    <td>{{ $assessment->self_assessment_value ?? '-' }}</td>
                    <td>
                        <div class="d-flex align-items-center">
                            {{-- Bagian Input Nilai (selalu aktif) --}}
                            <div style="width: 170px;">
                                {{-- [KODE BENAR] Tidak ada lagi @if. Input nilai akan selalu muncul. --}}
                                <div class="input-group input-group-sm">
                                    <input type="number" 
                                           name="assessments[{{ $assessment->id }}][nilai]" 
                                           class="form-control" 
                                           min="0" 
                                           max="100" 
                                           placeholder="Input Nilai"
                                           value="{{ $currentMatkulScore->nilai ?? '' }}">
                                    
                                    <input type="hidden" 
                                           name="assessments[{{ $assessment->id }}][matkul_assessment_id]" 
                                           value="{{ $assessment->id }}">
                                </div>
                            </div>
                    
                            {{-- Bagian Tampilan Nilai (Badge) --}}
                            <div class="ms-2">
                                <span class="bg-light {{ $currentMatkulScore && $currentMatkulScore->nilai !== null ? 'text-success' : 'text-secondary' }} border {{ $currentMatkulScore && $currentMatkulScore->nilai !== null ? 'border-success' : 'border-secondary' }} rounded p-2">
                                  {{ $currentMatkulScore && $currentMatkulScore->nilai !== null ? $currentMatkulScore->nilai : '-' }}
                                </span>
                            </div>
                        </div>
                    </td>
                  </tr>
                @endforeach
              </tbody>
            </table>

            @if ($assessorId)
            <div class="text-center mt-4">
              <button type="submit" class="btn btn-success">Simpan Penilaian</button>
            </div>
            @else
              <div class="alert alert-warning mt-4" role="alert">
                Anda tidak terdaftar sebagai asesor untuk mahasiswa ini. Anda tidak dapat memberikan penilaian.
              </div>
            @endif
          </form>
        @endif
      </div>
    </div>
    
  <!--  @if(!empty($rekomendasi))-->
  <!--      <div class="card mt-4">-->
  <!--        <div class="card-body">-->
  <!--          <h5 class="card-title">Rekomendasi Konversi Mata Kuliah</h5>-->
  <!--          <div class="table-responsive">-->
  <!--            <table class="table table-bordered">-->
  <!--              <thead>-->
  <!--                <tr>-->
  <!--                  <th>Mata Kuliah Tujuan</th>-->
  <!--                  <th>Mata Kuliah Asal</th>-->
  <!--                  <th>Nilai Asal</th>-->
  <!--                  <th>Tingkat Kemiripan</th>-->
  <!--                  <th>Status</th>-->
  <!--                </tr>-->
  <!--              </thead>-->
  <!--              <tbody>-->
  <!--                @foreach($rekomendasi as $rek)-->
  <!--                  <tr>-->
  <!--                    <td>{{ $rek['matkul_tujuan'] }}</td>-->
  <!--                    <td>{{ $rek['matkul_asal'] }}</td>-->
  <!--                    <td>{{ $rek['nilai_asal'] }}</td>-->
  <!--                    <td>{{ number_format($rek['similarity_score'] * 100, 2) }}%</td>-->
  <!--                    <td>-->
  <!--                      @if($rek['similarity_score'] >= 0.7)-->
  <!--                        <span class="badge bg-success">Sangat Direkomendasikan</span>-->
  <!--                      @elseif($rek['similarity_score'] >= 0.5)-->
  <!--                        <span class="badge bg-warning">Direkomendasikan</span>-->
  <!--                      @else-->
  <!--                        <span class="badge bg-danger">Tidak Direkomendasikan</span>-->
  <!--                      @endif-->
  <!--                    </td>-->
  <!--                  </tr>-->
  <!--                @endforeach-->
  <!--              </tbody>-->
  <!--            </table>-->
  <!--          </div>-->
  <!--        </div>-->
  <!--      </div>-->
  <!--    @endif-->
  </div>

  <!-- PENILAIAN MATKUL -->
  <div class="tab-content" id="penilaian-matkul">
    <h4 class="mt-4">Hasil Penilaian Mata Kuliah</h4>
    <div class="card">
      <div class="card-body mt-4">
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama Mata Kuliah</th>
                <th>Status</th>
                <th>Nilai</th>
                <th>Detail Penilaian</th>
                <!--<th>Aksi</th>-->
              </tr>
            </thead>
            <tbody>
              @forelse ($matkul as $index => $mk)
                @php
                   // Fetch the current assessor's score for this matkul
                   $matkulScore = $matkulScores[$mk->id] ?? null;

                   // Fetch the MatkulAssessment to display details
                   $matkulAssessment = $matkulAssessments->firstWhere('matkul_id', $mk->id);
                @endphp
                <tr>
                  <td>{{ $index + 1 }}</td>
                  <td>{{ $mk->nama_matkul ?? '-' }}</td>
                  <td>
                    @if($mk->isComplete)
                      <span class="badge {{ $mk->isLolos ? 'bg-success' : 'bg-danger' }}">
                        {{ $mk->isLolos ? 'Lolos' : 'Gagal' }}
                      </span>
                    @else
                      <span class="badge bg-warning">
                        Menunggu Penilaian ({{ $mk->completedAssessmentsCount }}/{{ $mk->requiredAssessments }})
                      </span>
                    @endif
                  </td>
                  <td>
                    <!--<span class="bg-light {{ $matkulScore && $matkulScore->nilai ? 'text-success' : 'text-secondary' }} border {{ $matkulScore && $matkulScore->nilai ? 'border-success' : 'border-secondary' }} rounded p-2">-->
                    <!--  {{ $matkulScore ? $matkulScore->nilai : 'Belum dinilai' }}-->
                    <!--</span>-->
                    <small>
                        <strong>Nama Assessor 1:</strong> 91 <br>
                        <strong>Nama Assessor 2:</strong> 84 <br>
                        <strong>Nama Assessor 3:</strong> 81
                    </small>
                  </td>
                  <td>
                    @if($matkulAssessment)
                      <small>
                        <strong>Self Assessment:</strong> {{ $matkulAssessment->self_assessment_value ?? '-' }}<br>
                        <strong>Nama Assessor 1:</strong> {{ $matkulAssessment->assessor1_assessment ?? '-' }}<br>
                        <strong>Nama Assessor 2:</strong> {{ $matkulAssessment->assessor2_assessment ?? '-' }}<br>
                        <strong>Nama Assessor 3:</strong> {{ $matkulAssessment->assessor3_assessment ?? '-' }}
                      </small>
                    @else
                      <span class="text-muted">Belum ada penilaian</span>
                    @endif
                  </td>
                  <!--<td>-->
                  <!--  @if($mk->isComplete && $mk->isLolos)-->
                  <!--    <form action="{{ route('nilai-matkul-input') }}" method="POST" class="d-inline">-->
                  <!--      @csrf-->
                  <!--      <input type="hidden" name="matkul_id" value="{{ $mk->id }}">-->
                  <!--      <input type="hidden" name="calon_mahasiswa_id" value="{{ $camaba->id }}">-->
                  <!--      <input type="hidden" name="assessor_id" value="{{ auth()->user()->assessor->id ?? '' }}">-->
                  <!--      <div class="input-group">-->
                  <!--        <input type="number" name="nilai" class="form-control form-control-sm" style="width: 80px" min="0" max="100" placeholder="Nilai">-->
                  <!--        <button type="submit" class="btn btn-primary btn-sm">Simpan</button>-->
                  <!--      </div>-->
                  <!--    </form>-->
                  <!--  @elseif(!$mk->isComplete)-->
                  <!--    <span class="text-muted">Menunggu penilaian lengkap</span>-->
                  <!--  @else-->
                  <!--    <span class="text-muted">Tidak dapat memberikan nilai</span>-->
                  <!--  @endif-->
                  <!--</td>-->
                </tr>
              @empty
                <tr>
                  <td colspan="6" class="text-center">Tidak ada mata kuliah yang tersedia</td>
                </tr>
              @endforelse
            </tbody>
          </table>
        </div>
      </div>
    </div>
    
    <!-- Modal -->
    <div class="modal fade" id="modalTambah" tabindex="-1" role="dialog" aria-labelledby="modalTambahLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="modalTambahLabel">Tambah Mata Kuliah</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form class="row g-3" action="{{ route('handle_matkul_input') }}" method="POST">
              @csrf
              <div class="col-6 my-3">
                <label for="matkul" class="form-label">Pilih Mata Kuliah</label>
                <select name="matkul_id" id="matkul2" class="form-select" required>
                  <option value="" disabled selected>Pilih Mata Kuliah</option>
                  @foreach($matkul2 as $item)
                    <option value="{{ $item->id }}">{{ $item->nama_matkul }}</option>
                  @endforeach
                </select>
              </div>
              <div class="form-group">
                <label for="nilai">Masukkan Nilai</label>
                <input type="number" id="nilai" name="nilai" class="form-control" required>
              </div>
              <input type="hidden" name="calon_mahasiswa_id" value="{{ $camaba->id }}">
              <input type="hidden" name="assessor_id" value="{{ auth()->user()->id }}">
              <button type="submit" class="btn btn-primary">Simpan</button>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
          </div>
        </div>
      </div>
    </div>

    <!--<div class="" id="rekomendasi">-->
    <!--  @if(!empty($rekomendasi))-->
    <!--    <div class="card mt-4">-->
    <!--      <div class="card-body">-->
    <!--        <h5 class="card-title">Rekomendasi Konversi Mata Kuliah</h5>-->
    <!--        <div class="table-responsive">-->
    <!--          <table class="table table-bordered">-->
    <!--            <thead>-->
    <!--              <tr>-->
    <!--                <th>Mata Kuliah Tujuan</th>-->
    <!--                <th>Mata Kuliah Asal</th>-->
    <!--                <th>Nilai Asal</th>-->
    <!--                <th>Tingkat Kemiripan</th>-->
    <!--                <th>Status</th>-->
    <!--              </tr>-->
    <!--            </thead>-->
    <!--            <tbody>-->
    <!--              @foreach($rekomendasi as $rek)-->
    <!--                <tr>-->
    <!--                  <td>{{ $rek['matkul_tujuan'] }}</td>-->
    <!--                  <td>{{ $rek['matkul_asal'] }}</td>-->
    <!--                  <td>{{ $rek['nilai_asal'] }}</td>-->
    <!--                  <td>{{ number_format($rek['similarity_score'] * 100, 2) }}%</td>-->
    <!--                  <td>-->
    <!--                    @if($rek['similarity_score'] >= 0.7)-->
    <!--                      <span class="badge bg-success">Sangat Direkomendasikan</span>-->
    <!--                    @elseif($rek['similarity_score'] >= 0.3)-->
    <!--                      <span class="badge bg-warning">Direkomendasikan</span>-->
    <!--                    @else-->
    <!--                      <span class="badge bg-danger">Tidak Direkomendasikan</span>-->
    <!--                    @endif-->
    <!--                  </td>-->
    <!--                </tr>-->
    <!--              @endforeach-->
    <!--            </tbody>-->
    <!--          </table>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--  @endif-->
    <!--</div>-->
  </div>

</main>

{{-- CPMK Modal --}}
<div class="modal fade" id="cpmkModal" tabindex="-1" aria-labelledby="cpmkModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="cpmkModalLabel">CPMK Mata Kuliah: <span id="matkulNameInModal"></span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>No</th>
                <th>CPMK</th>
              </tr>
            </thead>
            <tbody id="cpmkTableBody">
              <!-- CPMK data will be dynamically added here -->
            </tbody>
          </table>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>


<style>
  .nav-pills .nav-link.active,
  .nav-pills .show > .nav-link {
    background-color: #0d6efd;
    color: white !important;
    font-weight: bold;
    transition: all 0.3s ease;
  }

  .nav-pills .nav-link:hover {
    background-color: #1987fb;
    color: white !important;
  }

  .tab-content {
    display: none;
    animation: fadeIn 0.3s ease-in-out;
  }

  .tab-content.active {
    display: block;
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
</style>
<script>
  function showTab(tabName) {
    // Logika untuk menampilkan/menyembunyikan konten tab
    document.querySelectorAll('.tab-content').forEach(content => {
      content.classList.remove('active');
    });

    document.getElementById(tabName).classList.add('active');

    // Update kelas aktif pada tombol tab
    document.querySelectorAll('.nav-link').forEach(btn => {
      btn.classList.remove('active');
    });

    event.currentTarget.classList.add('active');
  }

  // Script untuk CPMK Modal
  document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi modal Bootstrap
    var cpmkModal = new bootstrap.Modal(document.getElementById('cpmkModal'));
    var matkulNameInModal = document.getElementById('matkulNameInModal');
    var cpmkTableBody = document.getElementById('cpmkTableBody');

    // Event listener untuk tombol View CPMK
    document.querySelectorAll('.view-cpmk-btn').forEach(button => {
      button.addEventListener('click', function() {
        const matkulId = this.getAttribute('data-matkul-id');
        const matkulName = this.getAttribute('data-matkul-name');

        matkulNameInModal.textContent = matkulName;
        cpmkTableBody.innerHTML = ''; // Clear previous table rows

        // Show loading message
        const loadingRow = document.createElement('tr');
        const loadingCell = document.createElement('td');
        loadingCell.setAttribute('colspan', '2');
        loadingCell.textContent = 'Loading CPMK...';
        loadingCell.style.textAlign = 'center';
        loadingRow.appendChild(loadingCell);
        cpmkTableBody.appendChild(loadingRow);

        // Fetch CPMK data
        fetch(`/assessor/matkul/${matkulId}/cpmk`)
          .then(response => {
            if (!response.ok) {
              throw new Error('Network response was not ok');
            }
            return response.json();
          })
          .then(data => {
            cpmkTableBody.innerHTML = ''; // Clear loading message
            if (data.length > 0) {
              data.forEach((cpmk, index) => {
                const row = document.createElement('tr');
                const noCell = document.createElement('td');
                const cpmkCell = document.createElement('td');

                noCell.textContent = index + 1;
                cpmkCell.textContent = cpmk.penjelasan;

                row.appendChild(noCell);
                row.appendChild(cpmkCell);
                cpmkTableBody.appendChild(row);
              });
            } else {
              const noCpmkRow = document.createElement('tr');
              const noCpmkCell = document.createElement('td');
              noCpmkCell.setAttribute('colspan', '2');
              noCpmkCell.textContent = 'Tidak ada CPMK untuk mata kuliah ini.';
              noCpmkCell.style.textAlign = 'center';
              noCpmkRow.appendChild(noCpmkCell);
              cpmkTableBody.appendChild(noCpmkRow);
            }
          })
          .catch(error => {
            console.error('Error fetching CPMK:', error);
            cpmkTableBody.innerHTML = ''; // Clear loading message
            const errorRow = document.createElement('tr');
            const errorCell = document.createElement('td');
            errorCell.setAttribute('colspan', '2');
            errorCell.textContent = 'Error loading CPMK.';
            errorCell.style.textAlign = 'center';
            errorRow.appendChild(errorCell);
            cpmkTableBody.appendChild(errorRow);
          });

        cpmkModal.show();
      });
    });
  });

  function validateForm() {
      const assessments = document.querySelectorAll('input[type="radio"]:checked');
      if (assessments.length === 0) {
          alert('Silakan pilih minimal satu penilaian untuk setiap mata kuliah yang akan dinilai.');
          return false;
      }
      return true;
  }
</script>
@endsection
</body>
</html>