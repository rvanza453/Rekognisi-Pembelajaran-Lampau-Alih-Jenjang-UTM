@extends('layout.admin')
@section('content')

  <main id="main" class="main">

    <div class="pagetitle">
    <h1>Atur Assessor Mahasiswa</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Atur Assessor Mahasiswa</li>
        </ol>
    </div><!-- End Page Title -->
    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title center" align="center">Atur Assessor Mahasiswa</h5>

              <!-- Dropdown for selecting Jurusan -->
              <form class="row g-3" action="{{ route('kelola-assessor-mahasiswa') }}" method="GET">
                <div class="col-6 my-3">
                </div>
              </form>

              <!-- Menampilkan pesan kesalahan atau sukses -->
              @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
              @endif

              @if (session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
              @endif

              

              <div class="container mt-5">
              <table class="table table-bordered">
                  <thead>
                      <tr>
                          <th>No</th>
                          <th>Nama</th>
                          <th>Program Studi</th>
                          <th>Assessor 1</th>
                          <th>Assessor 2</th>
                          <th>Assessor 3</th>
                          <th>Aksi</th>
                      </tr>
                  </thead>
                  <tbody>
                    @foreach($calon_mahasiswa as $index => $camaba)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $camaba->nama ?? '-'  }}</td>
                            <td>{{ $camaba->jurusan->nama_jurusan ?? '-'  }}</td>
                            <td>{{ $camaba->assessment->assessor1->nama ?? 'belum' }}</td>
                            <td>{{ $camaba->assessment->assessor2->nama ?? 'belum' }}</td>
                            <td>{{ $camaba->assessment->assessor3->nama ?? 'belum' }}</td>
                            <td>
                              <button class="btn btn-outline-primary" data-toggle="modal" data-target="#editModal" onclick="editData({{ $camaba->id }})">Edit</button>
                            </td>
                        </tr>
                    @endforeach  
                  </tbody>
              </table>
          </div>

         <!-- Modal -->
          <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h5 class="modal-title" id="editModalLabel">Edit Assessor</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                          </button>
                      </div>
                      <div class="modal-body">
                          <form id="editForm" method="POST" action="{{ route("kelola-assessor-mahasiswa-add") }}">
                            @csrf
                            <input type="hidden" name="calon_mahasiswa_id" id="calonMahasiswaId">
                            
                            <!-- Assessor 1 -->
                            <div class="form-group">
                                <label for="assessor1_id">Assessor 1</label>
                                <select class="form-select" id="assessor1_id" name="assessor1_id" required onchange="updateAssessorOptions()">
                                    <option value="">Pilih Assessor 1</option>
                                    @foreach($assessor as $assessor1)
                                        <option value="{{ $assessor1->id }}">{{ $assessor1->nama }}</option>
                                    @endforeach
                                </select>
                            </div>
                            
                            <!-- Assessor 2 -->
                            <div class="form-group">
                                <label for="assessor2_id">Assessor 2</label>
                                <select class="form-select" id="assessor2_id" name="assessor2_id"  onchange="updateAssessorOptions()">
                                    <option value="">Pilih Assessor 2</option>
                                    @foreach($assessor as $assessor2)
                                        <option value="{{ $assessor2->id }}">{{ $assessor2->nama }}</option>
                                    @endforeach
                                </select>
                            </div>
                            
                            <!-- Assessor 3 -->
                            <div class="form-group">
                                <label for="assessor3_id">Assessor 3</label>
                                <select class="form-select" id="assessor3_id" name="assessor3_id">
                                    <option value="">Pilih Assessor 3</option>
                                    @foreach($assessor as $assessor3)
                                        <option value="{{ $assessor3->id }}">{{ $assessor3->nama }}</option>
                                    @endforeach
                                </select>
                            </div>
                            
                            <button type="submit" class="btn btn-primary mt-3">Save changes</button>
                          </form>
                      </div>
                  </div>
              </div>
          </div>

          <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
          <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
          <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
          <script>
            function editData(mahasiswaId) {
                document.getElementById('calonMahasiswaId').value = mahasiswaId;
                
                // Find the table row for the selected mahasiswa
                const row = document.querySelector(`button[onclick="editData(${mahasiswaId})"]`).closest('tr');
                
                // Get current assessor names from the table cells
                const assessor1Name = row.cells[3].textContent.trim();
                const assessor2Name = row.cells[4].textContent.trim();
                const assessor3Name = row.cells[5].textContent.trim();

                // Map assessor names to their IDs using the allAssessors data
                const allAssessors = [ @foreach($assessor as $a) { id: '{{ $a->id }}', nama: '{{ $a->nama }}' }, @endforeach ];
                
                const assessor1Id = allAssessors.find(a => a.nama === assessor1Name)?.id || '';
                const assessor2Id = allAssessors.find(a => a.nama === assessor2Name)?.id || '';
                const assessor3Id = allAssessors.find(a => a.nama === assessor3Name)?.id || '';

                // Set dropdown values
                document.getElementById('assessor1_id').value = assessor1Id;
                document.getElementById('assessor2_id').value = assessor2Id;
                document.getElementById('assessor3_id').value = assessor3Id;
                
                // Update options based on the pre-filled values
                updateAssessorOptions();
                
                // Tampilkan modal
                var myModal = new bootstrap.Modal(document.getElementById('editModal'));
                myModal.show();
            }

            function updateAssessorOptions() {
                // Ambil semua dropdown assessor
                const assessor1 = document.getElementById('assessor1_id');
                const assessor2 = document.getElementById('assessor2_id');
                const assessor3 = document.getElementById('assessor3_id');
                
                // Daftar semua assessor yang tersedia
                const allAssessors = [
                    @foreach($assessor as $a)
                        { id: '{{ $a->id }}', nama: '{{ $a->nama }}' },
                    @endforeach
                ];
                
                // Ambil nilai yang sudah dipilih (termasuk nilai kosong)
                const selectedValues = [
                    assessor1.value,
                    assessor2.value,
                    assessor3.value
                ].filter(value => value !== ''); // Filter out empty values
                
                // Update setiap dropdown
                [assessor1, assessor2, assessor3].forEach((select) => {
                    const currentValue = select.value; // Get the currently selected value
                    
                    // Clear all options except the default one
                    select.innerHTML = '<option value="">Pilih Assessor ' + (select.id.slice(-1)) + '</option>';
                    
                    // Add available options
                    allAssessors.forEach(assessor => {
                         // Include the current value even if it's in selectedValues
                        if (!selectedValues.includes(assessor.id) || assessor.id === currentValue) {
                            const option = new Option(assessor.nama, assessor.id);
                            select.add(option);
                        }
                    });
                    
                    // Re-select the current value after options are updated
                    select.value = currentValue;
                });
            }

            // Initial update of options when the page loads
            document.addEventListener('DOMContentLoaded', updateAssessorOptions);

            // Tambahkan event listener untuk setiap dropdown
            document.getElementById('assessor1_id').addEventListener('change', updateAssessorOptions);
            document.getElementById('assessor2_id').addEventListener('change', updateAssessorOptions);
            document.getElementById('assessor3_id').addEventListener('change', updateAssessorOptions);
          </script>
          


            </div>
          </div>


        </div>
      </div>
    </section>

  </main><!-- End #main -->
@endsection
