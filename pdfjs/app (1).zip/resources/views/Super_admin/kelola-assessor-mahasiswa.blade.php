@extends('layout.super_admin')
@section('content')

  <main id="main" class="main">

    <div class="pagetitle">
    <h1>Atur Assessor Mahasiswa</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Atur Assessor Mahasiswa</li>
        </ol>
    </div><!-- End Page Title -->
    <section class="section">
      <div class="row">

        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title center" align="center">Atur Assessor Mahasiswa</h5>

              <!-- Dropdown for selecting Jurusan -->
              <form class="row g-3" action="{{ route('super.kelola-assessor-mahasiswa') }}" method="GET">
                <div class="col-6 my-3">
                  <label for="jurusan" class="form-label">Pilih Jurusan</label>
                  <div>
                    <select name="jurusan_id" id="jurusan" class="form-select" required onchange="this.form.submit()">
                      @foreach($jurusans as $jurusan)
                        <option value="{{ $jurusan->id }}" {{ $jurusan_id == $jurusan->id ? 'selected' : '' }}>{{ $jurusan->nama_jurusan }}</option>
                      @endforeach
                    </select>
                  </div>
                </div>
              </form>

              <!-- Menampilkan pesan kesalahan atau sukses -->
              @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
              @endif

              @if (session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
              @endif

              

              <div class="container mt-5">
              <table class="table table-bordered">
                  <thead>
                      <tr>
                          <th>No</th>
                          <th>Nama</th>
                          <th>Jurusan</th>
                          <th>Periode</th>
                          <th>Assessor 1</th>
                          <th>Assessor 2</th>
                          <th>Assessor 3</th>
                          <th>Aksi</th>
                      </tr>
                  </thead>
                  <tbody>
                    @forelse($calon_mahasiswa as $index => $mahasiswa)
                        <tr>
                        <th scope="row">{{ $index + 1 }}</th>
                        <td>{{ $mahasiswa->nama }}</td>
                        <td>{{ $mahasiswa->jurusan->nama_jurusan }}</td>
                        <td>{{ $mahasiswa->periode->tahun_ajaran }}</td>
                        <td>{{ $mahasiswa->assessment->assessor1->nama ?? '-' }}</td>
                        <td>{{ $mahasiswa->assessment->assessor2->nama ?? '-' }}</td>
                        <td>{{ $mahasiswa->assessment->assessor3->nama ?? '-' }}</td>
                            <td>
                          <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal{{ $mahasiswa->id }}">
                            Atur Assessor
                          </button>
                            </td>
                        </tr>

         <!-- Modal -->
                      <div class="modal fade" id="modal{{ $mahasiswa->id }}" tabindex="-1">
              <div class="modal-dialog">
                  <div class="modal-content">
                      <div class="modal-header">
                              <h5 class="modal-title">Atur Assessor untuk {{ $mahasiswa->nama }}</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                            <form action="{{ route('super.kelola-assessor-mahasiswa-add') }}" method="POST">
                              @csrf
                      <div class="modal-body">
                                <input type="hidden" name="calon_mahasiswa_id" value="{{ $mahasiswa->id }}">
                            
                                <div class="mb-3">
                                  <label for="assessor1" class="form-label">Assessor 1</label>
                                  <select name="assessor1_id" id="assessor1" class="form-select" required>
                                    <option value="">Pilih Assessor 1</option>
                                    @foreach($assessor as $a)
                                      <option value="{{ $a->id }}" {{ $mahasiswa->assessment && $mahasiswa->assessment->assessor_id_1 == $a->id ? 'selected' : '' }}>
                                        {{ $a->nama }}
                                      </option>
                                    @endforeach
                                </select>
                            </div>
                            
                                <div class="mb-3">
                                  <label for="assessor2" class="form-label">Assessor 2</label>
                                  <select name="assessor2_id" id="assessor2" class="form-select">
                                    <option value="">Pilih Assessor 2</option>
                                    @foreach($assessor as $a)
                                      <option value="{{ $a->id }}" {{ $mahasiswa->assessment && $mahasiswa->assessment->assessor_id_2 == $a->id ? 'selected' : '' }}>
                                        {{ $a->nama }}
                                      </option>
                                    @endforeach
                                </select>
                            </div>
                            
                                <div class="mb-3">
                                  <label for="assessor3" class="form-label">Assessor 3</label>
                                  <select name="assessor3_id" id="assessor3" class="form-select">
                                    <option value="">Pilih Assessor 3</option>
                                    @foreach($assessor as $a)
                                      <option value="{{ $a->id }}" {{ $mahasiswa->assessment && $mahasiswa->assessment->assessor_id_3 == $a->id ? 'selected' : '' }}>
                                        {{ $a->nama }}
                                      </option>
                                    @endforeach
                                </select>
                            </div>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
                    @empty
                      <tr>
                        <td colspan="8" class="text-center">Tidak ada data mahasiswa untuk jurusan ini</td>
                      </tr>
                    @endforelse
                  </tbody>
              </table>
          </div>

            </div>
          </div>


        </div>
      </div>
    </section>

  </main><!-- End #main -->
@endsection
