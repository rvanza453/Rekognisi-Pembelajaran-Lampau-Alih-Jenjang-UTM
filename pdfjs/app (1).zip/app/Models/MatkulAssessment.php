<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MatkulAssessment extends Model
{
    use HasFactory;

    protected $table = 'matkul_assessments';

    protected $fillable = [
        'calon_mahasiswa_id',
        'matkul_id',
        'self_assessment_value',
        'assessor1_assessment',
        'assessor2_assessment',
        'assessor3_assessment',
        'assessor1_id',
        'assessor2_id',
        'assessor3_id',
    ];

    public function calonMahasiswa()
    {
        return $this->belongsTo(Calon_mahasiswa::class);
    }

    public function matkul()
    {
        return $this->belongsTo(Matkul::class);
    }

    public function assessor1()
    {
        return $this->belongsTo(Assessor::class, 'assessor1_id');
    }

    public function assessor2()
    {
        return $this->belongsTo(Assessor::class, 'assessor2_id');
    }

    public function assessor3()
    {
        return $this->belongsTo(Assessor::class, 'assessor3_id');
    }
}
