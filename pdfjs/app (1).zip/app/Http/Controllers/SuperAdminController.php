<?php

namespace App\Http\Controllers;

use App\Models\Super_admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Jurusan;
use App\Models\Admin;
use App\Models\User;
use App\Models\Calon_mahasiswa;
use App\Models\Assessor;
use App\Models\Cpmk;
use App\Models\Matkul;
use App\Models\Assessment;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\Periode;

class SuperAdminController extends Controller
{
    public function __construct()
    {
        $this->middleware(['web', 'auth', 'super_admin']);
    }

    private function checkSuperAdmin()
    {
        if (!auth()->check()) {
            \Log::warning('Unauthorized access attempt - not authenticated', [
                'session_id' => session()->getId(),
                'session_data' => session()->all()
            ]);
            return redirect()->route('login')->with('error', 'Please login first');
        }

        if (auth()->user()->role !== 'super_admin') {
            \Log::warning('Unauthorized access attempt - wrong role', [
                'user_id' => auth()->id(),
                'user_role' => auth()->user() ? auth()->user()->role : 'not authenticated',
                'session_id' => session()->getId()
            ]);
            return redirect()->route('login')->with('error', 'Unauthorized access');
        }

        // Regenerate session ID periodically
        if (!session()->has('last_session_regeneration') || 
            now()->diffInMinutes(session('last_session_regeneration')) > 30) {
            session()->regenerate();
            session()->put('last_session_regeneration', now());
        }

        return true;
    }

    public function dashboard()
    {
        \Log::info('Accessing super admin dashboard', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role
        ]);
        $this->checkSuperAdmin();
        return view('Super_admin.dashboard');
    }

    public function profileView()
    {
        \Log::info('Accessing super admin profile view', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role
        ]);
        $this->checkSuperAdmin();
        $user = Auth::user();
        $admin = $user->admin ?? new Admin(['user_id' => $user->id]);
        return view('Super_admin.profile-admin', compact('admin','user'));
    }

    public function profile_edit_admin_view($id)
    {
        $admin = Admin::where('user_id', Auth::id())->findOrFail($id);
        return view('Super_admin.profile-edit-admin', compact('admin'));
    }

    public function profile_edit_admin(Request $request, $id)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'no_hp' => 'required|string|max:255',
            'alamat' => 'required|string|max:255',
            'foto' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $admin = Admin::where('user_id', Auth::id())->findOrFail($id);

        if ($request->hasFile('foto')) {
            $imageName = time().'.'.$request->foto->extension();  
            $request->foto->move(public_path('Data/profile_pict_admin'), $imageName);
            
            if ($admin->foto) {
                $oldImagePath = public_path('Data/profile_pict_admin/' . $admin->foto);
                if (file_exists($oldImagePath)) {
                    unlink($oldImagePath);
                }
            }
    
            $admin->foto = $imageName; 
            $admin->save();
        }

        $admin->update($request->except('foto'));

        return redirect()->route('super.profile-view');
    }

    public function account_assessor_table(Request $request)
    {
        \Log::info('Accessing account_assessor_table', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'request_params' => $request->all()
        ]);
        $this->checkSuperAdmin();
        $jurusans = Jurusan::all();
        $jurusan_id = $request->jurusan_id ?? ($jurusans->isEmpty() ? null : $jurusans[0]->id);
        $users_camaba = [];
        if ($jurusan_id) {
            $users_assessor = User::where('role', 'assessor')
                                ->whereHas('assessor', function($query) use ($jurusan_id) {
                                    $query->where('jurusan_id', $jurusan_id);
                                })->get();
        }
        return view('Super_admin.account-assessor-table', compact('users_assessor','jurusans','jurusan_id'));
    }

    public function account_assessor_add()
    {
        \Log::info('Accessing account_assessor_add', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role
        ]);
        $this->checkSuperAdmin();
        $jurusan = Jurusan::select('id','nama_jurusan')->get();
        return view('Super_admin.account-assessor-add', compact('jurusan'));
    }

    public function account_assessor_add_data(Request $request)
    {
        \Log::info('Attempting to add assessor', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'request_data' => $request->except(['password'])
        ]);
        $this->checkSuperAdmin();
        $request->validate([
            'email' => 'required|email|max:255|unique:users',
            'username' => 'required|string|max:255|unique:users',
            'password' => 'required|string|min:6',
            'nama' => 'required|string|max:255',
            'jurusan_id' => 'required|exists:jurusan,id',
        ]);

        try {
            $user = User::create([
                'email' => $request->email,
                'username' => $request->username,
                'password' => Hash::make($request->password),
                'role' => 'assessor'
            ]);

            Assessor::create([
                'user_id' => $user->id,
                'nama' => $request->nama,
                'jurusan_id' => $request->jurusan_id,
            ]);

            \Log::info('Assessor created successfully', [
                'user_id' => $user->id,
                'assessor_name' => $request->nama
            ]);

            return redirect()->route('super.account-assessor-table')->with('success', 'Assessor created successfully!');
        } catch (\Exception $e) {
            \Log::error('Error creating assessor', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->back()->with('error', 'Failed to create assessor: ' . $e->getMessage());
        }
    }

    public function account_user_table(Request $request)
    {
        \Log::info('Accessing account_user_table', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'request_params' => $request->all()
        ]);
        $this->checkSuperAdmin();
        $jurusans = Jurusan::all();
        $jurusan_id = $request->jurusan_id ?? ($jurusans->isEmpty() ? null : $jurusans[0]->id);
        $active_periodes = Periode::where('is_active', true)->get();
        $users_camaba = [];
        
        if ($jurusan_id && $active_periodes->isNotEmpty()) {
            $users_camaba = User::where('role', 'pendaftar')
                                ->whereHas('calon_mahasiswa', function($query) use ($jurusan_id, $active_periodes) {
                                    $query->where('jurusan_id', $jurusan_id)
                                          ->whereIn('periode_id', $active_periodes->pluck('id'));
                                })->get();
        }
        return view('Super_admin.account-user-table', compact('users_camaba','jurusans','jurusan_id'));
    }

    public function account_user_add()
    {
        \Log::info('Accessing account_user_add', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role
        ]);
        $this->checkSuperAdmin();
        $jurusan = Jurusan::all();
        $periodes = Periode::all();
        return view('Super_admin.account-user-add', compact('jurusan', 'periodes'));
    }

    public function account_user_add_data(Request $request)
    {
        \Log::info('Attempting to add user', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'request_data' => $request->except(['password'])
        ]);
        $this->checkSuperAdmin();
        try {
            $request->validate([
                'email' => 'required|email|max:255|unique:users',
                'username' => 'required|string|max:255|unique:users',
                'password' => 'required|string|min:6',
                'nama' => 'required|string|max:255',
                'jurusan_id' => 'required|exists:jurusan,id',
                'periode_id' => 'required|exists:periode,id',
            ]);

            $user = User::create([
                'email' => $request->email,
                'username' => $request->username,
                'password' => Hash::make($request->password),
                'role' => 'pendaftar'
            ]);

            Calon_mahasiswa::create([
                'user_id' => $user->id,
                'nama' => $request->nama,
                'jurusan_id' => $request->jurusan_id,
                'periode_id' => $request->periode_id,
            ]);

            \Log::info('User created successfully', [
                'user_id' => $user->id,
                'user_name' => $request->nama
            ]);

            return redirect()->route('super.account-user-table')->with('success', 'Pendaftar created successfully!');
        } catch (\Exception $e) {
            \Log::error('Error creating user', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->back()->with('error', 'Failed to create user: ' . $e->getMessage());
        }
    }

    public function account_admin_table(Request $request)
    {
        \Log::info('Accessing account_admin_table', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'request_params' => $request->all()
        ]);
        $this->checkSuperAdmin();
        $jurusans = Jurusan::all();
        $jurusan_id = $request->jurusan_id ?? ($jurusans->isEmpty() ? null : $jurusans[0]->id);
        $users_admin = [];
        if ($jurusan_id) {
            $users_admin = User::where('role', 'admin')
                                ->whereHas('admin', function($query) use ($jurusan_id) {
                                    $query->where('jurusan_id', $jurusan_id);
                                })->get();
        }
        return view('Super_admin.account-admin-table', compact('users_admin','jurusans','jurusan_id'));
    }

    public function account_admin_add()
    {
        \Log::info('Accessing account_admin_add', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role
        ]);
        $this->checkSuperAdmin();
        $jurusan = Jurusan::all();
        return view('Super_admin.account-admin-add', compact('jurusan'));
    }

    public function account_admin_add_data(Request $request)
    {
        \Log::info('Attempting to add admin', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'request_data' => $request->except(['password'])
        ]);
        $this->checkSuperAdmin();
        $request->validate([
            'email' => 'required|email|max:255|unique:users',
            'username' => 'required|string|max:255|unique:users',
            'password' => 'required|string|min:6',
            'nama' => 'required|string|max:255',
            'jurusan_id' => 'required|exists:jurusan,id',
        ]);

        try {
            $user = User::create([
                'email' => $request->email,
                'username' => $request->username,
                'password' => Hash::make($request->password),
                'role' => 'admin'
            ]);

            Admin::create([
                'user_id' => $user->id,
                'nama' => $request->nama,
                'jurusan_id' => $request->jurusan_id,
            ]);

            \Log::info('Admin created successfully', [
                'user_id' => $user->id,
                'admin_name' => $request->nama
            ]);

            return redirect()->route('super.account-admin-table')->with('success', 'Admin created successfully!');
        } catch (\Exception $e) {
            \Log::error('Error creating admin', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->back()->with('error', 'Failed to create admin: ' . $e->getMessage());
        }
    }

    public function kelola_assessor_table()
    {
        \Log::info('Accessing kelola_assessor_table', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role
        ]);
        $this->checkSuperAdmin();
        return view('Super_admin.kelola-assessor-table');
    }

    public function kelola_assessor_mahasiswa(Request $request)
    {
        \Log::info('Accessing kelola_assessor_mahasiswa', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'request_params' => $request->all()
        ]);
        $this->checkSuperAdmin();
        $jurusans = Jurusan::all();
        $jurusan_id = $request->jurusan_id ?? ($jurusans->isEmpty() ? null : $jurusans[0]->id);
        $calon_mahasiswa = [];
        $active_periodes = Periode::where('is_active', true)->get();

        if ($jurusan_id && $active_periodes->isNotEmpty()) {
            // Ambil mahasiswa dari jurusan yang dipilih dan periode aktif
            $calon_mahasiswa = Calon_mahasiswa::with([
                    'jurusan', 
                    'periode',
                    'assessment.assessor1', 
                    'assessment.assessor2', 
                    'assessment.assessor3'
                ])
                ->where('jurusan_id', $jurusan_id)
                ->whereIn('periode_id', $active_periodes->pluck('id'))
                ->get();

            // Ambil assessor dari jurusan yang dipilih
            $assessor = Assessor::where('jurusan_id', $jurusan_id)->get();
        } else {
            $assessor = collect();
        }

        return view('Super_admin.kelola-assessor-mahasiswa', compact('calon_mahasiswa', 'assessor', 'jurusans', 'jurusan_id'));
    }

    public function kelola_assessor_mahasiswa_add(Request $request)
    {
        \Log::info('Attempting to add assessor to mahasiswa', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'request_data' => $request->all()
        ]);
        $this->checkSuperAdmin();
        $validated = $request->validate([
            'calon_mahasiswa_id' => 'required|exists:calon_mahasiswa,id',
            'assessor1_id' => 'required|exists:assessor,id',
            'assessor2_id' => 'nullable|exists:assessor,id',
            'assessor3_id' => 'nullable|exists:assessor,id',
        ]);

        try {
            $mahasiswa = Calon_mahasiswa::find($validated['calon_mahasiswa_id']);
            $jurusan_id = $mahasiswa->jurusan_id;

            // Check if assigned assessors are from the same department
            $assessorIds = [
                $validated['assessor1_id'],
                $validated['assessor2_id'],
                $validated['assessor3_id'],
            ];

            foreach ($assessorIds as $assessorId) {
                if ($assessorId) { // Only check if an assessor is assigned
                    $assessor = Assessor::find($assessorId);
                    if ($assessor->jurusan_id !== $jurusan_id) {
                        return back()->withErrors(['message' => 'Assessor harus berasal dari jurusan yang sama dengan mahasiswa.']);
                    }
                }
            }

            // Check for duplicate assessors, ignoring nulls
            $assignedAssessorIds = array_filter($assessorIds); // Remove null values
            if (count($assignedAssessorIds) !== count(array_unique($assignedAssessorIds))) {
                return back()->withErrors(['message' => 'Assessor tidak boleh sama.']);
            }

            // Use updateOrCreate to save or update the Assessment record
            $assessment = Assessment::updateOrCreate(
                ['calon_mahasiswa_id' => $validated['calon_mahasiswa_id']],
                [
                    'jurusan_id' => $jurusan_id,
                    'assessor_id_1' => $validated['assessor1_id'],
                    'assessor_id_2' => $validated['assessor2_id'],
                    'assessor_id_3' => $validated['assessor3_id'],
                ]
            );

            // Now, update the matkul_assessments table for all matkuls of this student's major
            $matkuls = Matkul::where('jurusan_id', $jurusan_id)->get();

            foreach ($matkuls as $matkul) {
                // Find or create the MatkulAssessment record
                $matkulAssessment = \App\Models\MatkulAssessment::firstOrNew([
                    'calon_mahasiswa_id' => $validated['calon_mahasiswa_id'],
                    'matkul_id' => $matkul->id,
                ]);

                // If it's a new record, set initial values for assessment fields to avoid NOT NULL errors
                if (!$matkulAssessment->exists) {
                    $matkulAssessment->self_assessment_value = ''; // Or a suitable default based on schema
                    $matkulAssessment->assessor1_assessment = ''; // Or a suitable default
                    $matkulAssessment->assessor2_assessment = ''; // Or a suitable default
                    $matkulAssessment->assessor3_assessment = ''; // Or a suitable default
                }

                // Update the assessor IDs explicitly
                $matkulAssessment->assessor1_id = $validated['assessor1_id'];
                $matkulAssessment->assessor2_id = $validated['assessor2_id'];
                $matkulAssessment->assessor3_id = $validated['assessor3_id'];

                // Save the MatkulAssessment record. This will create it if it didn't exist or update it.
                $matkulAssessment->save();
            }

            \Log::info('Assessment created successfully', [
                'calon_mahasiswa_id' => $validated['calon_mahasiswa_id'],
                'jurusan_id' => $jurusan_id
            ]);

            return redirect()->route('super.kelola-assessor-mahasiswa')->with('success', 'Assessment berhasil dibuat!');
        } catch (\Exception $e) {
            \Log::error('Error creating assessment', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->back()->with('error', 'Failed to create assessment: ' . $e->getMessage());
        }
    }

    public function kelola_matkul_table(Request $request)
    {
        \Log::info('Accessing kelola_matkul_table', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'request_params' => $request->all()
        ]);
        $this->checkSuperAdmin();
        $jurusans = Jurusan::all();
        $jurusan_id = $request->jurusan_id ?? ($jurusans->isEmpty() ? null : $jurusans[0]->id);
        $matkuls = [];
        if ($jurusan_id) {
            $matkuls = Matkul::where('jurusan_id', $jurusan_id)->get();
        }
        return view('Super_admin.kelola-matkul-table', compact('matkuls','jurusans','jurusan_id'));
    }

    public function kelola_matkul_add_data(Request $request)
    {
        try {
            \Log::info('Validating mata kuliah data', [
                'nama_matkul' => $request->nama_matkul,
                'kode_matkul' => $request->kode_matkul,
                'jurusan_id' => $request->jurusan_id
            ]);

            $validator = \Validator::make($request->all(), [
                'nama_matkul' => [
                    'required',
                    'string',
                    'max:255',
                    function ($attribute, $value, $fail) use ($request) {
                        $exists = Matkul::where('jurusan_id', $request->jurusan_id)
                            ->where('nama_matkul', $value)
                            ->exists();
                        \Log::info('Checking nama_matkul uniqueness', [
                            'value' => $value,
                            'exists' => $exists
                        ]);
                        if ($exists) {
                            $fail('Mata kuliah dengan nama ini sudah ada di jurusan ini.');
                        }
                    }
                ],
                'jurusan_id' => 'required|exists:jurusan,id',
                'kode_matkul' => [
                    'nullable',
                    'string',
                    'max:20',
                    function ($attribute, $value, $fail) use ($request) {
                        if ($value) {
                            $exists = Matkul::where('jurusan_id', $request->jurusan_id)
                                ->where('kode_matkul', $value)
                                ->exists();
                            \Log::info('Checking kode_matkul uniqueness', [
                                'value' => $value,
                                'exists' => $exists
                            ]);
                            if ($exists) {
                                $fail('Mata kuliah dengan kode ini sudah ada di jurusan ini.');
                            }
                        }
                    }
                ],
                'sks' => 'nullable|integer|min:1|max:6',
            ]);

            if ($validator->fails()) {
                \Log::info('Validation failed', [
                    'errors' => $validator->errors()->toArray()
                ]);
                return redirect()->route('super.kelola-matkul-table')
                    ->withErrors($validator)
                    ->withInput();
            }

            $matkulName = $request->nama_matkul;
            $translatedName = $matkulName;

            try {
                $response = Http::withoutVerifying()->get('https://translate.googleapis.com/translate_a/single', [
                    'client' => 'gtx',
                    'sl' => 'auto',
                    'tl' => 'en',
                    'dt' => 't',
                    'q' => $matkulName
                ]);

                if ($response->successful()) {
                    $result = $response->json();
                    if (!empty($result[0][0][0])) {
                        $translatedName = $result[0][0][0];
                    }
                }
            } catch (\Exception $e) {
                \Log::error('Google Translate error: ' . $e->getMessage());
                
                try {
                    $response = Http::withoutVerifying()->post('https://libretranslate.de/translate', [
                        'q' => $matkulName,
                        'source' => 'id',
                        'target' => 'en'
                    ]);

                    if ($response->successful()) {
                        $result = $response->json();
                        $translatedName = $result['translatedText'];
                    }
                } catch (\Exception $e) {
                    \Log::error('Fallback translation error: ' . $e->getMessage());
                }
            }

            $synonyms = [$translatedName];
            
            try {
                $response = Http::get('http://localhost:5000/synonyms', [
                    'word' => strtolower($translatedName)
                ]);

                if ($response->successful()) {
                    $wordnetSynonyms = $response->json();
                    if (!empty($wordnetSynonyms)) {
                        $synonyms = array_merge($synonyms, $wordnetSynonyms);
                    }
                }
            } catch (\Exception $e) {
                \Log::error('WordNet service error: ' . $e->getMessage());
                
                $commonSynonyms = [
                    'programming' => ['coding', 'software development', 'computer programming'],
                    'database' => ['db', 'data management', 'data storage', 'dbms'],
                    'network' => ['networking', 'computer network', 'data communication'],
                    'algorithm' => ['algorithmic', 'computational method', 'problem solving'],
                    'security' => ['cybersecurity', 'information security', 'computer security'],
                    'system' => ['information system', 'computing system', 'it system'],
                    'analysis' => ['analytics', 'data analysis', 'system analysis'],
                    'design' => ['system design', 'software design', 'application design'],
                    'web' => ['website', 'web application', 'web development'],
                    'mobile' => ['mobile application', 'mobile development', 'app development'],
                    'artificial intelligence' => ['ai', 'machine learning', 'deep learning'],
                    'operating system' => ['os', 'system software', 'platform'],
                    'discrete' => ['discrete mathematics', 'discrete structure', 'finite mathematics'],
                    'calculus' => ['mathematical analysis', 'integral calculus', 'differential calculus'],
                    'statistics' => ['statistical analysis', 'data statistics', 'probability'],
                ];

                foreach ($commonSynonyms as $key => $values) {
                    if (stripos($translatedName, $key) !== false) {
                        $synonyms = array_merge($synonyms, $values);
                    }
                }
            }

            $synonyms[] = $matkulName;
            $synonyms[] = $translatedName;
            $synonyms = array_unique(array_filter($synonyms));

            $matkul = Matkul::create([
                'nama_matkul' => $matkulName,
                'jurusan_id' => $request->jurusan_id,
                'sinonim' => json_encode($synonyms),
                'kode_matkul' => $request->kode_matkul,
                'sks' => $request->sks
            ]);

            return redirect()->route('super.kelola-matkul-table')
                ->with('success', 'Mata Kuliah berhasil ditambahkan dengan ' . count($synonyms) . ' sinonim!');

        } catch (\Exception $e) {
            \Log::error('Error in kelola_matkul_add_data: ' . $e->getMessage());
            return redirect()->route('super.kelola-matkul-table')
                ->with('error', 'Terjadi kesalahan saat menambahkan mata kuliah. Silakan coba lagi.');
        }
    }

    public function edit_matkul(Request $request, Matkul $matkul)
    {
        $this->checkSuperAdmin();

        $request->validate([
            'nama_matkul' => [
                'required',
                'string',
                'max:255',
                function ($attribute, $value, $fail) use ($matkul) {
                    if (Matkul::where('jurusan_id', $matkul->jurusan_id)
                        ->where('nama_matkul', $value)
                        ->where('id', '!=', $matkul->id)
                        ->exists()) {
                        $fail('Mata kuliah dengan nama ini sudah ada di jurusan ini.');
                    }
                }
            ],
            'kode_matkul' => [
                'nullable',
                'string',
                'max:20',
                function ($attribute, $value, $fail) use ($matkul) {
                    if ($value && Matkul::where('jurusan_id', $matkul->jurusan_id)
                        ->where('kode_matkul', $value)
                        ->where('id', '!=', $matkul->id)
                        ->exists()) {
                        $fail('Mata kuliah dengan kode ini sudah ada di jurusan ini.');
                    }
                }
            ],
            'sks' => 'nullable|integer|min:1|max:6',
        ]);

        try {
            $matkulName = $request->nama_matkul;
            $translatedName = $matkulName;

            try {
                $response = Http::withoutVerifying()->get('https://translate.googleapis.com/translate_a/single', [
                    'client' => 'gtx',
                    'sl' => 'auto',
                    'tl' => 'en',
                    'dt' => 't',
                    'q' => $matkulName
                ]);

                if ($response->successful()) {
                    $result = $response->json();
                    if (!empty($result[0][0][0])) {
                        $translatedName = $result[0][0][0];
                    }
                }
            } catch (\Exception $e) {
                \Log::error('Google Translate error: ' . $e->getMessage());
                
                try {
                    $response = Http::withoutVerifying()->post('https://libretranslate.de/translate', [
                        'q' => $matkulName,
                        'source' => 'id',
                        'target' => 'en'
                    ]);

                    if ($response->successful()) {
                        $result = $response->json();
                        $translatedName = $result['translatedText'];
                    }
                } catch (\Exception $e) {
                    \Log::error('Fallback translation error: ' . $e->getMessage());
                }
            }

            $synonyms = [$translatedName];
            
            try {
                $response = Http::get('http://localhost:5000/synonyms', [
                    'word' => strtolower($translatedName)
                ]);

                if ($response->successful()) {
                    $wordnetSynonyms = $response->json();
                    if (!empty($wordnetSynonyms)) {
                        $synonyms = array_merge($synonyms, $wordnetSynonyms);
                    }
                } else {
                     \Log::warning('WordNet service returned non-successful status: ' . $response->status());
                }
            } catch (\Exception $e) {
                \Log::error('WordNet service error: ' . $e->getMessage());
                
                $commonSynonyms = [
                    'programming' => ['coding', 'software development', 'computer programming'],
                    'database' => ['db', 'data management', 'data storage', 'dbms'],
                    'network' => ['networking', 'computer network', 'data communication'],
                    'algorithm' => ['algorithmic', 'computational method', 'problem solving'],
                    'security' => ['cybersecurity', 'information security', 'computer security'],
                    'system' => ['information system', 'computing system', 'it system'],
                    'analysis' => ['analytics', 'data analysis', 'system analysis'],
                    'design' => ['system design', 'software design', 'application design'],
                    'web' => ['website', 'web application', 'web development'],
                    'mobile' => ['mobile application', 'mobile development', 'app development'],
                    'artificial intelligence' => ['ai', 'machine learning', 'deep learning'],
                    'operating system' => ['os', 'system software', 'platform'],
                    'discrete' => ['discrete mathematics', 'discrete structure', 'finite mathematics'],
                    'calculus' => ['mathematical analysis', 'integral calculus', 'differential calculus'],
                    'statistics' => ['statistical analysis', 'data statistics', 'probability'],
                ];

                foreach ($commonSynonyms as $key => $values) {
                    if (stripos($translatedName, $key) !== false) {
                        $synonyms = array_merge($synonyms, $values);
                    }
                }
            }

            $synonyms[] = $matkulName;
            $synonyms[] = $translatedName;
            $synonyms = array_unique(array_filter($synonyms));

            $matkul->update([
                'nama_matkul' => $matkulName,
                'kode_matkul' => $request->kode_matkul,
                'sks' => $request->sks,
                'sinonim' => json_encode($synonyms)
            ]);

            return redirect()->route('super.kelola-matkul-table')
                ->with('success', 'Mata Kuliah berhasil diperbarui dengan ' . count($synonyms) . ' sinonim!');

        } catch (\Exception $e) {
            \Log::error('Error in edit_matkul: ' . $e->getMessage());
            return redirect()->route('super.kelola-matkul-table')
                ->with('error', 'Terjadi kesalahan saat memperbarui mata kuliah. Silakan coba lagi.');
        }
    }

    public function kelola_cpmk_table($matkul_id)
    {
        \Log::info('Accessing kelola_cpmk_table', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'matkul_id' => $matkul_id
        ]);
        $this->checkSuperAdmin();
        $matkul = Matkul::findOrFail($matkul_id);
        $cpmks = Cpmk::where('matkul_id',$matkul_id)->get();
        return view('Super_admin.kelola-cpmk-table', compact('matkul','cpmks'));
    }

    public function create_data_cpmk($matkul_id)
    {
        \Log::info('Accessing create_data_cpmk', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'matkul_id' => $matkul_id
        ]);
        $this->checkSuperAdmin();
        $matkul = Matkul::findOrFail($matkul_id);
        return view('Super_admin.kelola-cpmk-table', compact('matkul'));
    }

    public function add_data_cpmk(Request $request)
    {
        \Log::info('Attempting to add CPMK', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'request_data' => $request->all()
        ]);
        $this->checkSuperAdmin();
        $request->validate([
            'penjelasan' => 'required|string',
            'matkul_id' => 'required|exists:matkul,id',
        ]);

        try {
            Cpmk::create([
                'penjelasan' => $request->penjelasan,
                'matkul_id' => $request->matkul_id,
            ]);

            \Log::info('CPMK created successfully', [
                'matkul_id' => $request->matkul_id
            ]);

            return redirect()->route('super.kelola-cpmk-table', $request->matkul_id)
                ->with('success', 'CPMK created successfully!');
        } catch (\Exception $e) {
            \Log::error('Error creating CPMK', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->back()->with('error', 'Failed to create CPMK: ' . $e->getMessage());
        }
    }

    public function delete_cpmk(Cpmk $cpmk)
    {
        \Log::info('Attempting to delete CPMK', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'cpmk_id' => $cpmk->id
        ]);
        $this->checkSuperAdmin();
        try {
            $cpmk->delete();
            \Log::info('CPMK deleted successfully', [
                'cpmk_id' => $cpmk->id
            ]);
            return back()->with('success', 'CPMK deleted successfully!');
        } catch (\Exception $e) {
            \Log::error('Error deleting CPMK', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return back()->with('error', 'Failed to delete CPMK: ' . $e->getMessage());
        }
    }

    public function delete_matkul(Matkul $matkul)
    {
        \Log::info('Attempting to delete matkul', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'matkul_id' => $matkul->id
        ]);
        $this->checkSuperAdmin();
        try {
            $matkul->delete();
            \Log::info('Matkul deleted successfully', [
                'matkul_id' => $matkul->id
            ]);
            return back()->with('success', 'Matkul deleted successfully!');
        } catch (\Exception $e) {
            \Log::error('Error deleting matkul', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return back()->with('error', 'Failed to delete matkul: ' . $e->getMessage());
        }
    }

    public function delete_user(User $user)
    {
        \Log::info('Attempting to delete user', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role,
            'target_user_id' => $user->id
        ]);
        $this->checkSuperAdmin();
        try {
            $user->delete();
            \Log::info('User deleted successfully', [
                'target_user_id' => $user->id
            ]);
            return back()->with('success', 'User deleted successfully!');
        } catch (\Exception $e) {
            \Log::error('Error deleting user', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return back()->with('error', 'Failed to delete user: ' . $e->getMessage());
        }
    }

    public function data_user_table()
    {
        \Log::info('Accessing data_user_table', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role
        ]);
        
        $this->checkSuperAdmin();
        
        $active_periodes = Periode::where('is_active', true)->get();
        $users_camaba = collect();
        
        if ($active_periodes->isNotEmpty()) {
            $users_camaba = User::where('role', 'pendaftar')
                ->with(['calon_mahasiswa' => function($query) use ($active_periodes) {
                    $query->whereIn('periode_id', $active_periodes->pluck('id'))
                        ->with(['jurusan', 'periode']);
                }])
                ->whereHas('calon_mahasiswa', function($query) use ($active_periodes) {
                    $query->whereIn('periode_id', $active_periodes->pluck('id'));
                })
                ->get();
        }

        return view('Super_admin.data-user-table', compact('users_camaba'));
    }

    public function data_assessor_table()
    {
        \Log::info('Accessing data_assessor_table', [
            'user_id' => auth()->id(),
            'user_role' => auth()->user()->role
        ]);
        $this->checkSuperAdmin();
        $assessor = Assessor::all();
        $users_assessor = User::where('role','assessor')->get();
        return view('Super_admin.data-assessor-table', compact('users_assessor','assessor'));
    }

    public function account_super_admin_table()
    {
        try {
            $this->checkSuperAdmin();
            Log::info('Super admin accessed account_super_admin_table', [
                'user_id' => auth()->id(),
                'user_role' => auth()->user()->role
            ]);

            $users_super_admin = User::where('role', 'super_admin')
                ->with('admin')
                ->get();

            return view('Super_admin.account-super-admin-table', compact('users_super_admin'));
        } catch (\Exception $e) {
            Log::error('Error in account_super_admin_table: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Terjadi kesalahan saat mengakses halaman.');
        }
    }

    public function account_super_admin_add()
    {
        try {
            $this->checkSuperAdmin();
            Log::info('Super admin accessed account_super_admin_add', [
                'user_id' => auth()->id(),
                'user_role' => auth()->user()->role
            ]);

            return view('Super_admin.account-super-admin-add');
        } catch (\Exception $e) {
            Log::error('Error in account_super_admin_add: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Terjadi kesalahan saat mengakses halaman.');
        }
    }

    public function account_super_admin_add_data(Request $request)
    {
        try {
            $this->checkSuperAdmin();
            Log::info('Super admin attempting to add new super admin', [
                'user_id' => auth()->id(),
                'user_role' => auth()->user()->role,
                'request_data' => $request->except(['password'])
            ]);

            $request->validate([
                'nama' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email',
                'username' => 'required|string|unique:users,username',
                'password' => 'required|string|min:3'
            ]);

            DB::beginTransaction();

            // Create user
            $user = User::create([
                'email' => $request->email,
                'username' => $request->username,
                'password' => Hash::make($request->password),
                'role' => 'super_admin'
            ]);

            // Create admin profile without jurusan_id for super admin
            Super_admin::create([
                'user_id' => $user->id,
                'nama' => $request->nama
            ]);

            DB::commit();

            Log::info('Super admin successfully added new super admin', [
                'user_id' => auth()->id(),
                'new_super_admin_id' => $user->id
            ]);

            return redirect()->route('super.account-super-admin-table')
                ->with('success', 'Super admin berhasil ditambahkan.');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error in account_super_admin_add_data: ' . $e->getMessage());
            return redirect()->back()
                ->withInput()
                ->with('error', 'Terjadi kesalahan saat menambahkan super admin: ' . $e->getMessage());
        }
    }

    public function kelola_periode()
    {
        try {
            $this->checkSuperAdmin();
            Log::info('Super admin accessed kelola_periode', [
                'user_id' => auth()->id(),
                'user_role' => auth()->user()->role
            ]);

            $periodes = Periode::all();
            return view('Super_admin.kelola-periode', compact('periodes'));
        } catch (\Exception $e) {
            Log::error('Error in kelola_periode: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Terjadi kesalahan saat mengakses halaman.');
        }
    }

    public function add_periode(Request $request)
    {
        try {
            $this->checkSuperAdmin();
            Log::info('Super admin attempting to add new periode', [
                'user_id' => auth()->id(),
                'request_data' => $request->all()
            ]);

            $request->validate([
                'tahun_ajaran' => 'required|string|unique:periode,tahun_ajaran'
            ]);

            Periode::create([
                'tahun_ajaran' => $request->tahun_ajaran,
                'is_active' => false
            ]);

            Log::info('Periode created successfully', [
                'tahun_ajaran' => $request->tahun_ajaran
            ]);

            return redirect()->route('super.kelola-periode')
                ->with('success', 'Periode berhasil ditambahkan.');
        } catch (\Exception $e) {
            Log::error('Error in add_periode: ' . $e->getMessage());
            return redirect()->back()
                ->withInput()
                ->with('error', 'Terjadi kesalahan saat menambahkan periode: ' . $e->getMessage());
        }
    }

    public function activate_periode($id)
    {
        try {
            $this->checkSuperAdmin();
            Log::info('Super admin attempting to activate periode', [
                'user_id' => auth()->id(),
                'periode_id' => $id
            ]);

            // Activate selected period without deactivating others
            $periode = Periode::findOrFail($id);
            $periode->update(['is_active' => true]);

            Log::info('Periode activated successfully', [
                'periode_id' => $id
            ]);

            return redirect()->route('super.kelola-periode')
                ->with('success', 'Periode berhasil diaktifkan.');
        } catch (\Exception $e) {
            Log::error('Error in activate_periode: ' . $e->getMessage());
            return redirect()->back()
                ->with('error', 'Terjadi kesalahan saat mengaktifkan periode: ' . $e->getMessage());
        }
    }

    public function delete_periode($id)
    {
        try {
            $this->checkSuperAdmin();
            Log::info('Super admin attempting to delete periode', [
                'user_id' => auth()->id(),
                'periode_id' => $id
            ]);

            $periode = Periode::findOrFail($id);

            // Check if periode is active
            if ($periode->is_active) {
                throw new \Exception('Tidak dapat menghapus periode yang sedang aktif.');
            }

            // Check if periode has any calon mahasiswa
            if ($periode->calon_mahasiswa()->exists()) {
                throw new \Exception('Tidak dapat menghapus periode yang memiliki data mahasiswa.');
            }

            $periode->delete();

            Log::info('Periode deleted successfully', [
                'periode_id' => $id
            ]);

            return redirect()->route('super.kelola-periode')
                ->with('success', 'Periode berhasil dihapus.');
        } catch (\Exception $e) {
            Log::error('Error in delete_periode: ' . $e->getMessage());
            return redirect()->back()
                ->with('error', 'Terjadi kesalahan saat menghapus periode: ' . $e->getMessage());
        }
    }

    public function deactivate_periode($id)
    {
        try {
            $this->checkSuperAdmin();
            Log::info('Super admin attempting to deactivate periode', [
                'user_id' => auth()->id(),
                'periode_id' => $id
            ]);

            $periode = Periode::findOrFail($id);
            $periode->update(['is_active' => false]);

            Log::info('Periode deactivated successfully', [
                'periode_id' => $id
            ]);

            return redirect()->route('super.kelola-periode')
                ->with('success', 'Periode berhasil dinonaktifkan.');
        } catch (\Exception $e) {
            Log::error('Error in deactivate_periode: ' . $e->getMessage());
            return redirect()->back()
                ->with('error', 'Terjadi kesalahan saat menonaktifkan periode: ' . $e->getMessage());
        }
    }
} 