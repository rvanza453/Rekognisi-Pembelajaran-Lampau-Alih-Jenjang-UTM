<?php

namespace App\Http\Controllers;
use App\Models\Assessor;
use App\Models\Jurusan;
use App\Models\Assessment;
use App\Models\Matkul;
use App\Models\Matkul_score;
use App\Models\Transkrip;
use App\Models\Cpmk;
use App\Models\Self_assessment_camaba;
use App\Models\Calon_mahasiswa;
use App\Models\bukti_alih_jenjang;
use App\Models\Periode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use App\Models\MatkulAssessment;

class Assessor_data_Controller extends Controller
{
    public function list_name_table(Request $request)
    {
        try {
            $user = Auth::user();
            if (!$user) {
                return redirect()->route('login')->with('error', 'Anda harus login terlebih dahulu.');
            }

            $assessor = Assessor::where('user_id', $user->id)->first();
            if ($assessor) {
                // Ambil semua periode yang aktif
                $active_periodes = Periode::where('is_active', true)->get();
                
                if ($active_periodes->isEmpty()) {
                    return redirect()->back()->with('warning', 'Tidak ada periode yang aktif saat ini.');
                }

                $assessments = Assessment::where(function ($query) use ($assessor) {
                    $query->where('assessor_id_1', $assessor->id)
                        ->orWhere('assessor_id_2', $assessor->id)
                        ->orWhere('assessor_id_3', $assessor->id);
                })->get();

                $mahasiswaIds = $assessments->pluck('calon_mahasiswa_id');
                
                // Filter calon mahasiswa berdasarkan periode aktif
                $camaba = Calon_mahasiswa::whereIn('id', $mahasiswaIds)
                    ->whereIn('periode_id', $active_periodes->pluck('id'))
                    ->get();

                \Log::info('Mahasiswa IDs:', ['ids' => $mahasiswaIds->toArray()]);
                \Log::info('Camaba count:', ['count' => $camaba->count()]);

                return view('Assessor/list-name-table', compact('camaba'));
            }

            return redirect()->back()->with('error', 'Data assessor tidak ditemukan');
        } catch (\Exception $e) {
            \Log::error('Error in list_name_table: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }

    public function detail_user($id)
    {
        try {
            Log::info('Accessing detail_user with ID: ' . $id);
            $user = Auth::user();
            if (!$user) {
                return redirect()->route('login')->with('error', 'Anda harus login terlebih dahulu.');
            }

            $assessor = Assessor::where('user_id', $user->id)->first();
            $camaba = Calon_mahasiswa::findOrFail($id);
            
            // Ambil transkrip mahasiswa
            $transkrip = Transkrip::where('calon_mahasiswa_id', $id)->first();
            
            // Ambil mata kuliah dari jurusan yang dituju
            $matkul = Matkul::where('jurusan_id', $camaba->jurusan_id)->get();

            // Ambil MatkulAssessment data for this student
            $matkulAssessments = MatkulAssessment::where('calon_mahasiswa_id', $id)
                                ->with('matkul')
                                ->get();

            // Process matkul to add assessment status and completion info
            $matkulWithStatus = $matkul->map(function ($mk) use ($camaba, $matkulAssessments) {
                $matkulAssessment = $matkulAssessments->firstWhere('matkul_id', $mk->id);

                $assignedAssessorsCount = 0;
                $completedAssessmentsCount = 0;
                $positiveAssessmentsCount = 0;
                $isComplete = false;
                $isLolos = false;
                $requiredAssessments = 0;
                $finalScore = null;

                if ($matkulAssessment) {
                    // Count assigned assessors
                    if ($matkulAssessment->assessor1_id) $assignedAssessorsCount++;
                    if ($matkulAssessment->assessor2_id) $assignedAssessorsCount++;
                    if ($matkulAssessment->assessor3_id) $assignedAssessorsCount++;

                    // [LOGIKA BARU] Jumlah penilai yang dibutuhkan HANYA asesor
                    $requiredAssessments = $assignedAssessorsCount;

                    // [LOGIKA BARU] Hitung penilaian yang selesai dan positif HANYA dari asesor.
                    // Self-assessment mahasiswa diabaikan dalam kalkulasi.
                    if ($matkulAssessment->assessor1_assessment) {
                        $completedAssessmentsCount++;
                        if (in_array($matkulAssessment->assessor1_assessment, ['Baik', 'Sangat Baik'])) {
                            $positiveAssessmentsCount++;
                        }
                    }

                    if ($matkulAssessment->assessor2_assessment) {
                        $completedAssessmentsCount++;
                        if (in_array($matkulAssessment->assessor2_assessment, ['Baik', 'Sangat Baik'])) {
                            $positiveAssessmentsCount++;
                        }
                    }

                    if ($matkulAssessment->assessor3_assessment) {
                        $completedAssessmentsCount++;
                        if (in_array($matkulAssessment->assessor3_assessment, ['Baik', 'Sangat Baik'])) {
                            $positiveAssessmentsCount++;
                        }
                    }

                    // [LOGIKA BARU] Penilaian dianggap selesai jika semua asesor yang ditugaskan telah menilai.
                    $isComplete = ($requiredAssessments > 0) && ($completedAssessmentsCount === $requiredAssessments);

                    // [LOGIKA BARU] Kalkulasi persentase hanya berdasarkan penilaian asesor.
                    $percentage = $isComplete && $requiredAssessments > 0 ? ($positiveAssessmentsCount / $requiredAssessments) * 100 : 0;
                    $isLolos = $isComplete ? ($percentage >= 50) : false;

                    // If the course has passed, calculate the final score
                    if ($isLolos) {
                        $scores = Matkul_score::where([
                            'matkul_id' => $mk->id,
                            'calon_mahasiswa_id' => $camaba->id
                        ])->whereNotNull('nilai')->get();

                        if ($scores->isNotEmpty()) {
                            $finalScore = $scores->avg('nilai');
                        }
                    }
                }

                // Add calculated status to the matkul object
                $mk->isComplete = $isComplete;
                $mk->isLolos = $isLolos;
                $mk->completedAssessmentsCount = $completedAssessmentsCount;
                $mk->requiredAssessments = $requiredAssessments;
                $mk->finalScore = $finalScore;

                return $mk;
            });

            // Jika ada transkrip, hitung rekomendasi
            $rekomendasi = [];
            if ($transkrip && $transkrip->mata_kuliah_transkrip) {
                $matkulTranskrip = is_string($transkrip->mata_kuliah_transkrip) ?
                    json_decode($transkrip->mata_kuliah_transkrip, true) :
                    $transkrip->mata_kuliah_transkrip;

                foreach ($matkul as $matkulTujuan) {
                    $maxSimilarity = 0;
                    $bestMatch = null;

                    $mappingTujuan = is_string($matkulTujuan->sinonim) ?
                        json_decode($matkulTujuan->sinonim, true) :
                        $matkulTujuan->sinonim ?? [];

                    if (!is_array($mappingTujuan)) {
                        $mappingTujuan = [];
                    }

                    foreach ($matkulTranskrip as $mk) {
                        $mappingAsal = $mk['mapping'] ?? [];

                        if (!is_array($mappingAsal)) {
                            $mappingAsal = [];
                        }

                        if (!empty($mappingAsal) && !empty($mappingTujuan)) {
                            $mappingAsalLower = array_map('mb_strtolower', $mappingAsal);
                            $mappingTujuanLower = array_map('mb_strtolower', $mappingTujuan);

                            $jaccardScore = $this->hitungJaccardSimilarity($mappingAsalLower, $mappingTujuanLower);
                            $cosineScore = $this->hitungCosineSimilarity($mappingAsalLower, $mappingTujuanLower);
                            $combinedScore = min(1.0, ($jaccardScore + $cosineScore) / 2);

                            if ($combinedScore > $maxSimilarity) {
                                $maxSimilarity = $combinedScore;
                                $bestMatch = [
                                    'matkul_asal' => $mk['nama'],
                                    'nilai_asal' => $mk['nilai'],
                                    'similarity_score' => $combinedScore
                                ];
                            }
                        }
                    }

                    if ($maxSimilarity >= 0.6 && $bestMatch) {
                        $rekomendasi[] = [
                            'matkul_tujuan' => $matkulTujuan->nama_matkul,
                            'matkul_asal' => $bestMatch['matkul_asal'],
                            'nilai_asal' => $bestMatch['nilai_asal'],
                            'similarity_score' => $bestMatch['similarity_score']
                        ];
                    }
                }

                usort($rekomendasi, function($a, $b) {
                    return $b['similarity_score'] <=> $a['similarity_score'];
                });
            }

            // Fetch Matkul_score data for the current assessor and student
            $matkulScores = Matkul_score::where('calon_mahasiswa_id', $id)
                                        ->where('assessor_id', $assessor->id ?? null)
                                        ->get()
                                        ->keyBy('matkul_id');

            return view('Assessor/detail-user', [
                'camaba' => $camaba,
                'matkul' => $matkulWithStatus,
                'matkul2' => $matkul,
                'rekomendasi' => $rekomendasi,
                'matkulAssessments' => $matkulAssessments,
                'matkulScores' => $matkulScores
            ]);
        } catch (\Exception $e) {
            Log::error('Error in detail_user: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }
    
    // public function form_user($matkul_id){
    //     $matkul = Matkul::findOrFail($matkul_id);

    //     $self_assessment_camaba = Self_assessment_camaba::with(['bukti', 'cpmk'])
    //         ->whereHas('cpmk', function ($query) use ($matkul_id) {
    //             $query->where('matkul_id', $matkul_id);
    //         })
    //         ->get();

    //     return view('Assessor/form-user', compact('matkul', 'self_assessment_camaba'));
    // }
    
    // public function form_user($matkul_id){
    //     $matkul = Matkul::findOrFail($matkul_id);
    
    //     $self_assessment_camaba = Self_assessment_camaba::with('cpmk')
    //         ->whereHas('cpmk', function ($query) use ($matkul_id) {
    //             $query->where('matkul_id', $matkul_id);
    //         })
    //         ->get();
    
    //     // Ubah cara mendapatkan assessor_id
    //     $user = auth()->user();
    //     $assessor = Assessor::where('user_id', $user->id)->first();
    //     $assessor_id = $assessor->id; // Ini akan mengambil id dari tabel assessors
            
    //     $camaba = $self_assessment_camaba->first()->calon_mahasiswa;
    //     $calon_mahasiswa_id = $camaba->id;
        
    //     // Tambahkan query untuk mengambil matkul score
    //     $matkulScore = Matkul_score::where([
    //         'matkul_id' => $matkul_id,
    //         'assessor_id' => $assessor_id,
    //         'calon_mahasiswa_id' => $calon_mahasiswa_id
    //     ])->first();
        
    //     return view('Assessor/form-user', compact('matkul', 'self_assessment_camaba', 'camaba', 'calon_mahasiswa_id', 'assessor_id', 'matkulScore'));
    // }
    public function input_calculate(Request $request)
    {
        try {
            Log::info('Request data:', [
                'assessor_id' => $request->assessor_id,
                'all_data' => $request->all()
            ]);
    
            // Validasi input
            $validated = $request->validate([
                'calon_mahasiswa_id' => 'required|exists:calon_mahasiswa,id',
                'matkul_id' => 'required|exists:matkul,id',
                'assessor_id' => 'required|exists:assessor,id',
            ]);
    
            // Find the MatkulAssessment for this course and student
            $matkulAssessment = \App\Models\MatkulAssessment::where([
                'matkul_id' => $request->matkul_id,
                'calon_mahasiswa_id' => $request->calon_mahasiswa_id
            ])->first();

            if (!$matkulAssessment) {
                 // If no MatkulAssessment exists, we can't calculate status based on assessments
                 // We might want to handle this case, perhaps setting status to 'Belum Dinilai' or similar
                $status = 'Belum Dinilai';
                $percentage = 0;
            } else {
                // Calculate status based on self-assessment and assessor assessments with new weighting
                $assignedAssessorsCount = 0;
                $completedAssessmentsCount = 0;
                $positiveAssessmentsCount = 0;
                $requiredAssessments = 0;
                
                // Count assigned assessors
                if ($matkulAssessment->assessor1_id) $assignedAssessorsCount++;
                if ($matkulAssessment->assessor2_id) $assignedAssessorsCount++;
                if ($matkulAssessment->assessor3_id) $assignedAssessorsCount++;

                $requiredAssessments = $assignedAssessorsCount + 1; // +1 for self-assessment

                // Count completed and positive assessments
                if ($matkulAssessment->self_assessment_value && $matkulAssessment->self_assessment_value !== '') {
                    $completedAssessmentsCount++;
                    if (in_array($matkulAssessment->self_assessment_value, ['Baik', 'Sangat Baik'])) {
                        $positiveAssessmentsCount++;
                    }
                }

                if ($matkulAssessment->assessor1_id && $matkulAssessment->assessor1_assessment && $matkulAssessment->assessor1_assessment !== '') {
                    $completedAssessmentsCount++;
                    if (in_array($matkulAssessment->assessor1_assessment, ['Baik', 'Sangat Baik'])) {
                        $positiveAssessmentsCount++;
                    }
                }

                if ($matkulAssessment->assessor2_id && $matkulAssessment->assessor2_assessment && $matkulAssessment->assessor2_assessment !== '') {
                    $completedAssessmentsCount++;
                    if (in_array($matkulAssessment->assessor2_assessment, ['Baik', 'Sangat Baik'])) {
                        $positiveAssessmentsCount++;
                    }
                }

                if ($matkulAssessment->assessor3_id && $matkulAssessment->assessor3_assessment && $matkulAssessment->assessor3_assessment !== '') {
                    $completedAssessmentsCount++;
                    if (in_array($matkulAssessment->assessor3_assessment, ['Baik', 'Sangat Baik'])) {
                        $positiveAssessmentsCount++;
                    }
                }

                // Determine completion
                $isComplete = ($matkulAssessment->self_assessment_value !== null && $completedAssessmentsCount === $requiredAssessments);

                // Calculate percentage and Lolos/Gagal status only if complete
                $percentage = $isComplete && $requiredAssessments > 0 ? ($positiveAssessmentsCount / $requiredAssessments) * 100 : 0;
                $status = $isComplete ? ($percentage >= 50 ? 'Lolos' : 'Gagal') : 'Menunggu Penilaian';
            }

            // Simpan ke database
            $result = Matkul_score::updateOrCreate(
                [
                    'matkul_id' => $request->matkul_id,
                    'assessor_id' => $request->assessor_id,
                    'calon_mahasiswa_id' => $request->calon_mahasiswa_id,
                ],
                [
                    'status' => $status,
                    'score' => $percentage,
                    'updated_at' => now()
                ]
            );

            // Redirect berdasarkan status
            return redirect()->route('detail-user', ['id' => $request->calon_mahasiswa_id])
                ->with('success', 'Status penilaian berhasil diperbarui. Status: ' . $status);

        } catch (\Exception $e) {
            Log::error('Error saving score: ' . $e->getMessage(), [
                'request_data' => $request->all()
            ]);
            return redirect()->back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }

    
    public function input_nilai_matkul(Request $request)
    {
        try {
            // Log data request untuk debugging
            Log::info('Request data:', [
                'assessor_id' => $request->assessor_id,
                'all_data' => $request->all()
            ]);

            // Validasi input
            $validated = $request->validate([
                'nilai' => 'required|integer|min:0|max:100',
                'calon_mahasiswa_id' => 'required|exists:calon_mahasiswa,id',
                'matkul_id' => 'required|exists:matkul,id',
                'assessor_id' => 'required|exists:assessor,id',
            ]);

            // Check if the matkul has passed the assessment phase
            $matkulAssessment = \App\Models\MatkulAssessment::where([
                'matkul_id' => $request->matkul_id,
                'calon_mahasiswa_id' => $request->calon_mahasiswa_id
            ])->first();

            if (!$matkulAssessment) {
                throw new \Exception('Assessment data not found for this course.');
            }

            // Get the current status from Matkul_score
            $currentScore = \App\Models\Matkul_score::where([
                'matkul_id' => $request->matkul_id,
                'assessor_id' => $request->assessor_id,
                'calon_mahasiswa_id' => $request->calon_mahasiswa_id
            ])->first();

            if (!$currentScore || $currentScore->status !== 'Lolos') {
                throw new \Exception('Cannot input numeric score for a course that has not passed the assessment phase.');
            }

            // Update or create the Matkul_score record
            $matkulScore = \App\Models\Matkul_score::updateOrCreate(
                [
                    'matkul_id' => $request->matkul_id,
                    'assessor_id' => $request->assessor_id,
                    'calon_mahasiswa_id' => $request->calon_mahasiswa_id,
                ],
                [
                    'nilai' => $request->nilai,
                    'status' => 'Lolos', // Keep the status as Lolos
                    'updated_at' => now()
                ]
            );

            // Redirect back to the detail page to show the updated nilai
            return redirect()->route('detail-user', ['id' => $request->calon_mahasiswa_id])
                ->with('success', 'Nilai berhasil disimpan.');
            
        } catch (\Exception $e) {
            Log::error('Error menyimpan nilai: ' . $e->getMessage(), [
                'request_data' => $request->all()
            ]);
            return redirect()->back()->with('error', 'Terjadi kesalahan: ' . $e->getMessage());
        }
    }

    public function handleMatkulInput(Request $request)
    {
        try {
            // Dapatkan assessor_id yang benar
            $user = Auth::user();
            $assessor = Assessor::where('user_id', $user->id)->first();
            
            if (!$assessor) {
                throw new \Exception('Assessor tidak ditemukan');
            }
    
            $validated = $request->validate([
                'calon_mahasiswa_id' => 'required|exists:calon_mahasiswa,id',
                'matkul_id' => 'required|exists:matkul,id',
                'nilai' => 'required|numeric'
            ]);
    
            $result = Matkul_score::updateOrCreate(
                [
                    'matkul_id' => $request->matkul_id,
                    'assessor_id' => $assessor->id, // Gunakan assessor_id yang benar
                    'calon_mahasiswa_id' => $request->calon_mahasiswa_id,
                ],
                [
                    'status' => 'Lolos',
                    'nilai' => $request->nilai,
                    'score' => 80,
                    'updated_at' => now(),
                ]
            );
    
            return redirect()->back()->with('success', 'Data berhasil disimpan.');
        } catch (\Exception $e) {
            Log::error('Terjadi kesalahan:', ['message' => $e->getMessage()]);
            return redirect()->back()->with('error', 'Gagal menyimpan data: ' . $e->getMessage());
        }
    }

    public function showMatkulList($calon_mahasiswa_id)
    {
        // Ambil mata kuliah yang sudah dinilai oleh assessor saat ini
        $matkul_dinilai = Matkul_score::with('matkul') // Pastikan relasi 'matkul' didefinisikan di model
            ->where('calon_mahasiswa_id', $calon_mahasiswa_id)
            ->where('assessor_id', auth()->user()->id)
            ->get();
    
        // Data untuk dropdown tambah mata kuliah
        $matkul = Matkul::all();
    
        // Calon mahasiswa terkait
        $camaba = CalonMahasiswa::findOrFail($calon_mahasiswa_id);
    
        return view('nama_view', compact('matkul_dinilai', 'matkul', 'camaba'));
    }

    
    public function profile_view_assessor()
    {
        $user = Auth::user();
    
        // Pastikan user login ada
        if (!$user) {
            return redirect()->route('login')->with('error', 'Anda harus login terlebih dahulu.');
        }
    
        // Pastikan assessor ditemukan
        $assessor = Assessor::where('user_id', $user->id)->first();
        if (!$assessor) {
            return redirect()->route('profile-view-assessor')->with('error', 'Assessor tidak ditemukan.');
        }
    
        return view('Assessor/profile-view-assessor', compact('assessor', 'user'));
    }

    
    public function profile_assessor_edit_view($id){
        $assessor = Assessor::findOrFail($id);
        return view('Assessor/profile-edit-assessor', compact('assessor'));
    }
    
    public function profile_edit_assessor(Request $request, $id){
        $request->validate([
            'nama' => 'required|string|max:225',
            'alamat' => 'required|string|max:225',
            'no_hp' => 'required|string|max:225',
            'foto' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048', // Validasi untuk gambar
        ]);

        $assessor = Assessor::findOrFail($id);

        if ($request->hasFile('foto')) {
        $imageName = time().'.'.$request->foto->extension();
        $request->foto->move(public_path('Data/profile_pict_assesor'), $imageName);
    
        // Hapus gambar lama jika ada
        if ($assessor->foto) {
            Storage::delete('Data/profile_pict_assesor/' . $assessor->foto);
        }
    
        $assessor->foto = $imageName;
        }

        $assessor->update($request->except('foto'));

        return redirect()->route('profile-view-assessor');
    }

    public function view_transkrip($filename)
    {
        // Cari transkrip berdasarkan filename
        $transkrip = Transkrip::where('file', $filename)->firstOrFail();
    
        $path = public_path('Data/Transkrip/' . $filename);
    
        if (!file_exists($path)) {
            abort(404);
        }
    
        $fileExtension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
        if ($fileExtension === 'pdf') {
            // Untuk file PDF, tampilkan menggunakan response()->file()
            return response()->file($path, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'inline; filename="' . $filename . '"'
            ]);
        } else {
            // Untuk file gambar
            return response()->file($path, [
                'Content-Type' => mime_content_type($path)
            ]);
        }
    }

    private function hitungJaccardSimilarity($set1, $set2) 
    {
        if (empty($set1) || empty($set2)) {
            return 0;
        }

        $intersection = array_intersect($set1, $set2);
        $union = array_unique(array_merge($set1, $set2));
        
        if (count($union) == 0) {
            return 0;
        }
        
        return count($intersection) / count($union);
    }

    private function hitungCosineSimilarity($vector1, $vector2) 
    {
        // Gabungkan semua term yang unik
        $allTerms = array_unique(array_merge($vector1, $vector2));
        
        // Inisialisasi vektor dengan nilai 0
        $v1 = array_fill_keys($allTerms, 0);
        $v2 = array_fill_keys($allTerms, 0);
        
        // Isi vektor dengan frekuensi term
        foreach ($vector1 as $term) {
            $v1[$term]++;
        }
        foreach ($vector2 as $term) {
            $v2[$term]++;
        }
        
        // Hitung dot product dan magnitudes
        $dotProduct = 0;
        $magnitude1 = 0;
        $magnitude2 = 0;
        
        foreach ($allTerms as $term) {
            $dotProduct += $v1[$term] * $v2[$term];
            $magnitude1 += $v1[$term] * $v1[$term];
            $magnitude2 += $v2[$term] * $v2[$term];
        }
        
        $magnitude1 = sqrt($magnitude1);
        $magnitude2 = sqrt($magnitude2);
        
        // Hindari pembagian dengan nol
        if ($magnitude1 == 0 || $magnitude2 == 0) {
            return 0;
        }
        
        return $dotProduct / ($magnitude1 * $magnitude2);
    }

    public function view_bukti_alih_jenjang($filename)
    {
        // Cari bukti berdasarkan filename
        $bukti = bukti_alih_jenjang::where('file', $filename)->firstOrFail();
    
        $path = public_path('Data/Bukti_alih_jenjang/' . $filename);
    
        if (!file_exists($path)) {
            abort(404);
        }
    
        $fileExtension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
        if ($fileExtension === 'pdf') {
            // Untuk file PDF, tampilkan menggunakan response()->file()
            return response()->file($path, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'inline; filename="' . $filename . '"'
            ]);
        } else {
            // Untuk file gambar
            return response()->file($path, [
                'Content-Type' => mime_content_type($path)
            ]);
        }
    }

    public function download_bukti_alih_jenjang($filename)
    {
        // Cari bukti berdasarkan filename
        $bukti = bukti_alih_jenjang::where('file', $filename)->firstOrFail();
    
        $path = public_path('Data/Bukti_alih_jenjang/' . $filename);
    
        if (!file_exists($path)) {
            abort(404);
        }
    
        return response()->download($path, $filename);
    }

    public function saveMatkulAssessorAssessment(Request $request)
    {
        \Log::info('Starting unified assessment and score save', [
            'user_id' => auth()->id(),
            'request_data' => $request->all()
        ]);
    
        try {
            $assessorId = (int)$request->input('assessor_id');
            $calonMahasiswaId = $request->input('calon_mahasiswa_id');
            $assessmentsData = $request->input('assessments', []);
    
            if (empty($assessmentsData)) {
                return redirect()->back()->with('warning', 'Tidak ada data penilaian yang dikirim.');
            }
    
            $matkulIdsToUpdate = [];
    
            // TAHAP 1: Simpan Penilaian Asesor (Radio Buttons)
            foreach ($assessmentsData as $assessmentId => $data) {
                if (empty($data['value'])) continue;
    
                $matkulAssessment = MatkulAssessment::find($data['matkul_assessment_id']);
                if (!$matkulAssessment) continue;
    
                $assessorSlot = null;
                if ($matkulAssessment->assessor1_id == $assessorId) $assessorSlot = 'assessor1_assessment';
                elseif ($matkulAssessment->assessor2_id == $assessorId) $assessorSlot = 'assessor2_assessment';
                elseif ($matkulAssessment->assessor3_id == $assessorId) $assessorSlot = 'assessor3_assessment';
    
                if ($assessorSlot) {
                    $matkulAssessment->$assessorSlot = $data['value'];
                    $matkulAssessment->save();
                    $matkulIdsToUpdate[] = $matkulAssessment->matkul_id;
                }
            }
    
            // TAHAP 2: Perbarui Status Kelulusan Kolektif (Lolos/Gagal)
            foreach (array_unique($matkulIdsToUpdate) as $matkulId) {
                $this->updateMatkulStatus($calonMahasiswaId, $matkulId);
            }
    
            // [KODE BENAR] TAHAP 3: Simpan atau Perbarui Nilai Numerik Secara Independen
            foreach ($assessmentsData as $assessmentId => $data) {
                if (!isset($data['nilai']) || $data['nilai'] === null || $data['nilai'] === '') {
                    continue;
                }
    
                $matkulAssessment = MatkulAssessment::find($data['matkul_assessment_id']);
                if (!$matkulAssessment) {
                    continue;
                }
    
                Matkul_score::updateOrCreate(
                    [
                        'matkul_id' => $matkulAssessment->matkul_id,
                        'assessor_id' => $assessorId,
                        'calon_mahasiswa_id' => $calonMahasiswaId,
                    ],
                    [
                        'nilai' => $data['nilai'],
                    ]
                );
    
                \Log::info('Nilai numerik untuk asesor berhasil disimpan/diperbarui.', [
                    'matkul_id' => $matkulAssessment->matkul_id, 
                    'assessor_id' => $assessorId,
                    'nilai' => $data['nilai']
                ]);
            }
    
            return redirect()->back()->with('success', 'Penilaian dan nilai berhasil disimpan.');
    
        } catch (\Exception $e) {
            \Log::error('Error in saveMatkulAssessorAssessment: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->back()->with('error', 'Terjadi kesalahan saat menyimpan data: ' . $e->getMessage());
        }
    }

    private function updateMatkulStatus($calonMahasiswaId, $matkulId)
    {
        $matkulAssessment = \App\Models\MatkulAssessment::where([
            'matkul_id' => $matkulId,
            'calon_mahasiswa_id' => $calonMahasiswaId
        ])->first();

        if (!$matkulAssessment) {
            return;
        }

        $assignedAssessorsCount = 0;
        $completedAssessmentsCount = 0;
        $positiveAssessmentsCount = 0;

        // Count assigned assessors
        if ($matkulAssessment->assessor1_id) $assignedAssessorsCount++;
        if ($matkulAssessment->assessor2_id) $assignedAssessorsCount++;
        if ($matkulAssessment->assessor3_id) $assignedAssessorsCount++;

        // Count completed and positive assessments
        if ($matkulAssessment->self_assessment_value) {
            $completedAssessmentsCount++;
            if (in_array($matkulAssessment->self_assessment_value, ['Baik', 'Sangat Baik'])) {
                $positiveAssessmentsCount++;
            }
        }

        if ($matkulAssessment->assessor1_assessment) {
            $completedAssessmentsCount++;
            if (in_array($matkulAssessment->assessor1_assessment, ['Baik', 'Sangat Baik'])) {
                $positiveAssessmentsCount++;
            }
        }

        if ($matkulAssessment->assessor2_assessment) {
            $completedAssessmentsCount++;
            if (in_array($matkulAssessment->assessor2_assessment, ['Baik', 'Sangat Baik'])) {
                $positiveAssessmentsCount++;
            }
        }

        if ($matkulAssessment->assessor3_assessment) {
            $completedAssessmentsCount++;
            if (in_array($matkulAssessment->assessor3_assessment, ['Baik', 'Sangat Baik'])) {
                $positiveAssessmentsCount++;
            }
        }

        // Determine if all required assessments are complete
        $requiredAssessments = $assignedAssessorsCount + 1; // +1 for self-assessment
        $isComplete = $completedAssessmentsCount === $requiredAssessments;

        // Calculate percentage and determine status
        $percentage = $isComplete && $requiredAssessments > 0 ? ($positiveAssessmentsCount / $requiredAssessments) * 100 : 0;
        $status = $isComplete ? ($percentage >= 50 ? 'Lolos' : 'Gagal') : 'Menunggu Penilaian';

        // Update Matkul_score records for all assessors
        $assessors = [$matkulAssessment->assessor1_id, $matkulAssessment->assessor2_id, $matkulAssessment->assessor3_id];
        foreach ($assessors as $assessorId) {
            if ($assessorId) {
                \App\Models\Matkul_score::updateOrCreate(
                    [
                        'matkul_id' => $matkulId,
                        'assessor_id' => $assessorId,
                        'calon_mahasiswa_id' => $calonMahasiswaId,
                    ],
                    [
                        'status' => $status,
                        'score' => $percentage,
                        'updated_at' => now()
                    ]
                );
            }
        }
    }

    public function getCpmkByMatkul($matkulId)
    {
        \Log::info('Accessing getCpmkByMatkul', ['matkul_id' => $matkulId]);
        try {
            $cpmks = Cpmk::where('matkul_id', $matkulId)->get();
            \Log::info('CPMK fetched successfully', ['count' => $cpmks->count()]);
            return response()->json($cpmks);
        } catch (\Exception $e) {
            \Log::error('Error in getCpmkByMatkul', ['error' => $e->getMessage(), 'matkul_id' => $matkulId]);
            return response()->json(['message' => 'Error fetching CPMK'], 500);
        }
    }

    public function downloadIjazah($calon_mahasiswa_id)
    {
        try {
            // Temukan data calon mahasiswa
            $camaba = \App\Models\Calon_mahasiswa::findOrFail($calon_mahasiswa_id);

            // Pastikan calon mahasiswa memiliki data ijazah
            if (!$camaba->ijazah || !$camaba->ijazah->file) {
                return back()->with('error', 'File ijazah mahasiswa tidak ditemukan.');
            }

            $filePath = $camaba->ijazah->file;
            $path = public_path($filePath);

            // Periksa apakah file ada di server
            if (!file_exists($path)) {
                return back()->with('error', 'File ijazah tidak ditemukan di server.');
            }

            $filename = basename($filePath);
            $mimeType = mime_content_type($path);

            return response()->download($path, $filename, [
                'Content-Type' => $mimeType,
                'Content-Disposition' => 'attachment; filename="' . $filename . '"'
            ]);

        } catch (\Exception $e) {
            \Log::error('Error downloading ijazah for assessor: ' . $e->getMessage(), ['calon_mahasiswa_id' => $calon_mahasiswa_id]);
            return back()->with('error', 'Terjadi kesalahan saat mengunduh file ijazah. Silakan coba lagi.');
        }
    }
}
