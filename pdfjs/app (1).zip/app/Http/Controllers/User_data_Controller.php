<?php

namespace App\Http\Controllers;

use App\Models\Calon_mahasiswa;
use App\Models\Self_assessment_camaba;
use App\Models\Jurusan;
use App\Models\Ijazah;
use App\Models\Matkul;
use App\Models\Matkul_score;
use App\Models\User;
use App\Models\Cpmk;
use App\Models\Bukti;
use App\Models\bukti_alih_jenjang;
use App\Models\Transkrip;
use App\Models\MatkulAssessment;
use GuzzleHttp\Promise\Create;
use Illuminate\Auth\Events\Validated;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Dompdf\Dompdf;
use Dompdf\Options;
use Illuminate\Support\Facades\Http;

class User_data_Controller extends Controller
{
    
    public function profile_view_camaba(){
        $user = Auth::user();
        $calon_mahasiswa = $user->calon_mahasiswa;
        return view('User/profile-view-camaba', compact('calon_mahasiswa','user'));
    }
    public function profile_edit_camaba_view($id){
        $calon_mahasiswa = Calon_mahasiswa::findOrFail($id);
        return view('User/profile-edit-camaba', compact('calon_mahasiswa'));
    }
    public function profile_edit_camaba(Request $request, $id){
        $request->validate([
            'nama' => 'required|string|max:255',
            'tempat_lahir' => 'required|string|max:255',
            'tanggal_lahir' => 'required|date',
            'nomor_rumah' => 'nullable|string|max:255',
            'nomor_kantor' => 'nullable|string|max:255',
            'kelamin' => 'required|string|max:255',
            'alamat' => 'required|string|max:255',
            'kota' => 'required|string|max:255',
            'provinsi' => 'required|string|max:255',
            'kode_pos' => 'required|string|max:255',
            'kebangsaan' => 'nullable|string|max:255',
            'foto' => 'image|mimes:jpeg,png,jpg,gif,svg|max:5049',
            'nomor_telepon' => 'nullable|string|max:255',
        ]);

        $calon_mahasiswa = Calon_Mahasiswa::findOrFail($id);
        if ($request->hasFile('foto')) {
            $imageName = time().'.'.$request->foto->extension();  
            $request->foto->move(public_path('Data/profile_pict_camaba'), $imageName);
    
            // Hapus foto lama jika ada
            if ($calon_mahasiswa->foto) {
                $oldImagePath = public_path('Data/profile_pict_camaba/' . $calon_mahasiswa->foto);
                if (file_exists($oldImagePath)) {
                    unlink($oldImagePath);
                }
            }
    
            $calon_mahasiswa->foto = $imageName; 
            $calon_mahasiswa->save(); // Simpan perubahan pada model secara terpisah
        }
    
        $calon_mahasiswa->update($request->except('foto'));

        return redirect()->route('profile-view-camaba');
    }
    
    public function view_ijazah(){
        $user = Auth::user();
    
        // Cek apakah camaba yang login memiliki ijazah
        if ($user->calon_mahasiswa && $user->calon_mahasiswa->ijazah) {
            $ijazah = $user->calon_mahasiswa->ijazah;
            return view('User.view-ijazah', compact('ijazah'));
        } else {
            // Jika camaba belum memiliki ijazah, redirect ke halaman tambah ijazah
            return redirect()->route('ijazah-add-view')->with('message', 'Silakan tambah ijazah terlebih dahulu.');
        }
    }
    
    public function ijazah_edit_view($id)
    {
        $user = auth()->user();
        if ($user->role !== 'pendaftar') {
            abort(403, 'Unauthorized action');
        }
    
        $ijazah = Ijazah::where('id', $id)
                        ->where('calon_mahasiswa_id', $user->calon_mahasiswa->id)
                        ->firstOrFail();
    
        return view('User.ijazah-edit', compact('ijazah'));
    }
    
    public function ijazah_add_view(){
        // Get the logged-in user's calon_mahasiswa data
    $user = Auth::user();
    $calon_mahasiswa = $user->calon_mahasiswa;
    
        // Pass calon_mahasiswa data to the view if needed
    return view('User.ijazah-add', compact('calon_mahasiswa'));
    }
    
    
    public function ijazah_add(Request $request){
    $request->validate([
            'institusi_pendidikan' => 'nullable|string|max:255',
            'jenjang' => 'nullable|string|max:10',
            'kota' => 'nullable|string|max:255',
            'provinsi' => 'nullable|string|max:255',
            'negara' => 'nullable|string|max:255',
            'fakultas' => 'nullable|string|max:255',
            'jurusan' => 'nullable|string|max:255',
            'ipk_nilai' => 'nullable|string|max:10',
            'tahun_lulus' => 'nullable|integer|min:1900|max:'.(date('Y')),
            'file' => 'required|mimes:pdf,jpg,jpeg,png|max:2048',
    ]);
    
        // $filePath = $request->file('file')->store('Data/Ijazah', 'public');
        $file = $request->file('file');
        $filename = time() . '_' . $file->getClientOriginalName();
        $filePath = 'Data/Ijazah/' . $filename;
    
        $file->move(public_path('Data/Ijazah'), $filename);
    
        Ijazah::create([
            'calon_mahasiswa_id' => Auth::user()->calon_mahasiswa->id,
            'institusi_pendidikan' => $request->institusi_pendidikan,
            'jenjang' => $request->jenjang,
            'kota' => $request->kota,
            'provinsi' => $request->provinsi,
            'negara' => $request->negara,
            'fakultas' => $request->fakultas,
            'jurusan' => $request->jurusan,
            'ipk_nilai' => $request->ipk_nilai,
            'tahun_lulus' => $request->tahun_lulus,
            'file' => $filePath,
        ]);
    
        return redirect()->route('view-ijazah')->with('success', 'Ijazah berhasil ditambahkan.');
    }
    
    public function ijazah_edit(Request $request, $id)
    {
        $request->validate([
            'institusi_pendidikan' => 'nullable|string|max:255',
            'provinsi' => 'nullable|string|max:255',
            'kota' => 'nullable|string|max:255',
            'negara' => 'nullable|string|max:255',
            'fakultas' => 'nullable|string|max:255',
            'jurusan' => 'nullable|string|max:255',
            'ipk_nilai' => 'nullable|string|max:255',
            'tahun_lulus' => 'nullable|Integer',
            'file' => 'sometimes|mimes:pdf,jpg,jpeg,png|max:2048',
        ]);
    
        $ijazah = Ijazah::findOrFail($id);
    
        if ($request->hasFile('file')) {
            $fileExtension = $request->file('file')->extension();
    
            $filename = time() . '.' . $fileExtension;
            $filePath = 'Data/Ijazah/' . $filename;
    
            $request->file('file')->move(public_path('Data/Ijazah/'), $filename);
    
            if ($ijazah->file) {
                $oldFilePath = public_path($ijazah->file);
                if (file_exists($oldFilePath)) {
                    unlink($oldFilePath);
                }
            }
    
            $ijazah->file = $filePath; 
        }
    
        $ijazah->update($request->except('file'));
        
        return redirect()->route('view-ijazah');
    }

    public function download_ijazah($filename)
    {
        $user = Auth::user();
        $ijazah = Ijazah::where('file', 'Data/Ijazah/' . $filename)
            ->where('calon_mahasiswa_id', $user->calon_mahasiswa->id)
            ->firstOrFail();

        $path = public_path('Data/Ijazah/' . $filename);

        if (!file_exists($path)) {
            abort(404);
        }

        $fileExtension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $mimeType = mime_content_type($path);

        return response()->file($path, [
            'Content-Type' => $mimeType,
            'Content-Disposition' => 'attachment; filename="' . $filename . '"'
        ]);
    }

    public function self_assessment(Request $request){
        $calon_mahasiswa = auth()->user()->calon_mahasiswa;
        $matkul = Matkul::where('jurusan_id', $calon_mahasiswa->jurusan_id)->select('id','nama_matkul')->get();
        $matkul_id = $request->matkul_id ?? ($matkul->isEmpty() ? null : $matkul[0]->id);
        $cpmks = [];
        if ($matkul_id) {
            $cpmks = Cpmk::where('matkul_id', $matkul_id)->get();
        }
        return view('User/self-assessment',compact('matkul','cpmks','matkul_id'));
    }

    public function add_self_assessment(Request $request)
    {
        $user = auth()->user();
        if ($user->role !== 'pendaftar') {
            abort(403, 'Unauthorized action');
        }

        $request->validate([
            'nilai' => 'required|array',
            'nilai.*' => 'required|in:Sangat Baik,Baik,Tidak Pernah',
            'bukti' => 'array',
            'bukti.*.nama' => 'nullable|string|max:255',
            'bukti.*.jenis_bukti' => 'nullable|string|max:255',
            'bukti.*.file' => 'nullable|file|mimes:pdf,jpg,jpeg,png,mp4,mkv|max:20069'
        ]);

        $calon_mahasiswa = auth()->user()->calon_mahasiswa;

        // Loop through each CPMK that has a value
        foreach ($request->nilai as $cpmk_id => $nilai) {
            // Inisialisasi $bukti dengan null
            $bukti = null;

            if ($nilai === 'Tidak Pernah') {
                // If "Tidak Pernah" is selected, skip file upload
                $bukti = Bukti::create([
                    'nama' => '', 
                    'jenis_bukti' => '', 
                    'file' => '', 
                ]);
            } else {
                // Handle the file upload for other options
                if ($request->hasFile('bukti.' . $cpmk_id . '.file')) {
                    $file = $request->file('bukti.' . $cpmk_id . '.file');
                    $filename = time() . '_' . $file->getClientOriginalName();
                    $filePath = 'Data/bukti_self_assessment/' . $filename;

                    $file->move(public_path('Data/bukti_self_assessment/'), $filename);

                    // Save Bukti
                    $bukti = Bukti::create([
                        'nama' => $request->bukti[$cpmk_id]['nama'],
                        'jenis_bukti' => $request->bukti[$cpmk_id]['jenis_bukti'],
                        'file' => $filePath,
                    ]);
                } else {
                    // Create an empty bukti if no file is uploaded
                    $bukti = Bukti::create([
                        'nama' => '', 
                        'jenis_bukti' => '', 
                        'file' => '', 
                    ]);
                }
            }

            // Save Self Assessment dengan updateOrCreate
            Self_assessment_camaba::updateOrCreate(
                [
                    'calon_mahasiswa_id' => $calon_mahasiswa->id,
                    'cpmk_id' => $cpmk_id
                ],
                [
                    'nilai' => $nilai,
                    'bukti_id' => $bukti->id
                ]
            );
        }

        return redirect()->route('self-assessment-table')->with('success', 'Penilaian dan bukti berhasil disimpan.');
    }

    public function self_assessment_table(Request $request){
        $user = auth()->user();
        if ($user->role !== 'pendaftar'){
            abort(403, 'Unauthorized action');
        }
        $calon_mahasiswa = $user->calon_mahasiswa;
        $matkuls = Matkul::where('jurusan_id', $calon_mahasiswa->jurusan_id)->select('id', 'nama_matkul')->get();
        $matkul_id = $request->get('matkul_id') ?? ($matkuls->isEmpty() ? null : $matkuls[0]->id);

        // Data untuk edit mode
        $editMode = $request->get('edit_mode', false);
        $existingAssessments = [];
        
        if ($editMode && $matkul_id) {
            $existingAssessments = Self_assessment_camaba::with(['bukti', 'cpmk'])
                ->where('calon_mahasiswa_id', $calon_mahasiswa->id)
                ->whereHas('cpmk', function($query) use ($matkul_id) {
                    $query->where('matkul_id', $matkul_id);
                })
                ->get()
                ->keyBy('cpmk_id');
        }

        $cpmks = [];
        $assessments = [];
        if ($matkul_id) {
            $cpmks = Cpmk::where('matkul_id', $matkul_id)->get();
            $assessments = $calon_mahasiswa->self_assessment_camaba()->with('cpmk')->whereHas('cpmk', function($query) use ($matkul_id) {
                $query->where('matkul_id', $matkul_id);
            })->whereNotNull('nilai')->get();
        }
        return view('User/self-assessment-table', compact('assessments','matkuls','matkul_id','cpmks','editMode','existingAssessments'));
    }
    public function view_nilai(){
        $calon_mahasiswa_id = auth()->user()->calon_mahasiswa->id;
        $assessments = DB::table('self_assessment_camaba')  // Menggunakan nama tabel yang benar
            ->join('cpmk', 'self_assessment_camaba.cpmk_id', '=', 'cpmk.id')
            ->select('cpmk.matkul_id')
            ->where('self_assessment_camaba.calon_mahasiswa_id', $calon_mahasiswa_id)
            ->groupBy('cpmk.matkul_id')
            ->get();

        // array untuk menyimpan hasil penilaian
        $matkulScores = [];
        
        foreach($assessments as $assessment) {
            // Cek nilai dari ketiga assessor untuk setiap mata kuliah
            $scores = Matkul_score::where('calon_mahasiswa_id', $calon_mahasiswa_id)
                ->where('matkul_id', $assessment->matkul_id)
                ->get();
                
            $matkul = Matkul::find($assessment->matkul_id);
            
            // Hitung jumlah assessor yang sudah menilai
            $assessorCount = $scores->count();
            // Hitung jumlah status 'Lolos'
            $lolosCount = $scores->where('status', 'Lolos')->count();
            
            // Tentukan status berdasarkan mayoritas
            $status = 'Belum Ditentukan';
            if ($assessorCount >= 2) { 
                if ($lolosCount >= 2) {
                    $status = 'Lolos';
                } elseif (($assessorCount - $lolosCount) >= 2) {
                    $status = 'Gagal';
                }
            }

            $matkulScores[] = [
                'matkul' => $matkul,
                'status' => $status,
                'nilai' => $assessorCount == 3 ? number_format($scores->pluck('nilai')->avg(), 2) : '-',
                'is_complete' => $assessorCount >= 2 // Ubah ke minimal 2 assessor
            ];
        }
        return view('User.view-nilai', compact('matkulScores'));
    }
    public function delete_self_assessment($id)
    {
        $user = auth()->user();
        if ($user->role !== 'pendaftar') {
            abort(403, 'Unauthorized action');
        }
    
        try {
            // Ambil data assessment berdasarkan ID dan user (melalui calon_mahasiswa)
            $assessment = $user->calon_mahasiswa
                             ->self_assessment_camaba()
                             ->findOrFail($id);
            
            // Hapus file bukti jika ada
            if ($assessment->bukti && Storage::exists($assessment->bukti)) {
                Storage::delete($assessment->bukti);
            }
            
            $assessment->delete();
            
            return redirect()->back()
                            ->with('success', 'Penilaian berhasil dihapus');
                            
        } catch (\Exception $e) {
            return redirect()->back()
                            ->with('error', 'Gagal menghapus penilaian');
        }
    }

    public function input_transkrip(){
        $user = Auth::user();
        $calon_mahasiswa = $user->calon_mahasiswa;
        
        // Cek apakah mahasiswa sudah memiliki transkrip
        $existing_transkrip = Transkrip::where('calon_mahasiswa_id', $calon_mahasiswa->id)->first();
        
        return view('User.input-transkrip', compact('calon_mahasiswa', 'existing_transkrip'));
    }
    
    public function transkrip_add_data(Request $request)
    {
        $user = auth()->user();
        if ($user->role !== 'pendaftar') {
            abort(403, 'Unauthorized action');
        }
        
        // Validasi input file
        $request->validate([
            'file' => 'required|mimes:pdf|max:2048',
        ]);

        // Proses upload file
        $file = $request->file('file');
        $filename = time() . '_' . $file->getClientOriginalName();
        $file->move(public_path('Data/Transkrip'), $filename);

        // Buat record transkrip baru tanpa mata kuliah
        $transkrip = Transkrip::create([
            'file' => $filename,
            'calon_mahasiswa_id' => $user->calon_mahasiswa->id,
            'mata_kuliah_transkrip' => [], // Array kosong untuk diisi nanti
            'mapping_results' => null
        ]);

        return redirect()->route('input-transkrip')
            ->with('success', 'File transkrip berhasil diunggah. Silakan input mata kuliah.');
    }

    public function input_matkul_transkrip($id)
    {
        $transkrip = Transkrip::findOrFail($id);
        return view('User.input-matkul-transkrip', compact('transkrip'));
    }

    public function store_matkul_transkrip(Request $request, $id)
    {
        $transkrip = Transkrip::findOrFail($id);
        
        $request->validate([
            'mata_kuliah.nama' => 'required|string',
            'mata_kuliah.nilai' => 'required|string'
        ]);

        try {
            // Proses mata kuliah baru
            $matkulBaru = [
                'nama' => $request->input('mata_kuliah.nama'),
                'nilai' => $request->input('mata_kuliah.nilai')
            ];
            
            // Deteksi bahasa dan translasi
            $matkulName = $matkulBaru['nama'];
            $translatedName = $matkulName;

            try {
                // Gunakan Google Translate API
                $response = Http::withoutVerifying()->get('https://translate.googleapis.com/translate_a/single', [
                    'client' => 'gtx',
                    'sl' => 'auto',
                    'tl' => 'en',
                    'dt' => 't',
                    'q' => $matkulName
                ]);

                if ($response->successful()) {
                    $result = $response->json();
                    if (!empty($result[0][0][0])) {
                        $translatedName = $result[0][0][0];
                        \Log::info("Translated: {$matkulName} -> {$translatedName}");
                    }
                }
            } catch (\Exception $e) {
                \Log::error('Translation error: ' . $e->getMessage());
            }

            // Get WordNet synonyms
            $mapping = [$translatedName]; // Default include translated name
            try {
                $wordnetResponse = Http::get('http://wordnet.igsindonesia.org/synonyms', [
                    'word' => strtolower($translatedName)
                ]);

                if ($wordnetResponse->successful()) {
                    $wordnetSynonyms = $wordnetResponse->json();
                    if (!empty($wordnetSynonyms)) {
                        $mapping = array_merge($mapping, $wordnetSynonyms);
                    }
                    \Log::info("WordNet synonyms for {$translatedName}: " . json_encode($wordnetSynonyms));
                }
            } catch (\Exception $e) {
                \Log::error('WordNet error: ' . $e->getMessage());
                
                // Fallback: Tambahkan sinonim umum berdasarkan kata kunci
                $commonSynonyms = [
                    'programming' => ['coding', 'software development', 'computer programming'],
                    'database' => ['db', 'data management', 'data storage', 'dbms'],
                    'network' => ['networking', 'computer network', 'data communication'],
                    'algorithm' => ['algorithmic', 'computational method', 'problem solving'],
                    'security' => ['cybersecurity', 'information security', 'computer security'],
                    'system' => ['information system', 'computing system', 'it system'],
                    // ... tambahkan sinonim lainnya sesuai kebutuhan
                ];

                foreach ($commonSynonyms as $key => $values) {
                    if (stripos($translatedName, $key) !== false) {
                        $mapping = array_merge($mapping, $values);
                    }
                }
            }

            // Add original name to mapping
            $mapping[] = $matkulName;
            $mapping = array_unique(array_filter($mapping));

            // Prepare new mata kuliah data
            $newMatkul = [
                'nama' => $matkulName,
                'nama_en' => $translatedName,
                'nilai' => $matkulBaru['nilai'],
                'mapping' => $mapping
            ];

            // Get existing mata kuliah dan tambahkan yang baru
            $existingMatkul = $transkrip->mata_kuliah_transkrip ?? [];
            $existingMatkul[] = $newMatkul;

            // Update transkrip
            $transkrip->update([
                'mata_kuliah_transkrip' => $existingMatkul
            ]);

            \Log::info('Mata kuliah berhasil ditambahkan: ' . json_encode($newMatkul));

            return redirect()->route('input-transkrip')
                ->with('success', 'Mata kuliah berhasil ditambahkan');

        } catch (\Exception $e) {
            \Log::error('Error in store_matkul_transkrip: ' . $e->getMessage());
            return redirect()->route('input-transkrip')
                ->with('error', 'Terjadi kesalahan saat menambahkan mata kuliah');
        }
    }

    private function hitungSimilarity($mataKuliahTranskrip)
    {
        $matkulDatabase = Matkul::all();
        $rekomendasi = [];

        foreach ($mataKuliahTranskrip as $mkTranskrip) {
            foreach ($matkulDatabase as $mkDB) {
                // Normalize names for comparison - convert to lowercase and trim
                $namaTranskrip = mb_strtolower(trim($mkTranskrip['nama']));
                $namaMatkul = mb_strtolower(trim($mkDB->nama_matkul));
                
                // Check for exact name match
                $isExactNameMatch = $namaTranskrip === $namaMatkul;
                
                // Get normalized mappings - convert all to lowercase and trim
                $mappingTranskrip = is_array($mkTranskrip['mapping']) ? 
                    array_map(function($item) {
                        return mb_strtolower(trim($item));
                    }, $mkTranskrip['mapping']) : 
                    array_map(function($item) {
                        return mb_strtolower(trim($item));
                    }, array_values((array)$mkTranskrip['mapping']));
                
                $mappingMatkul = is_array($mkDB->sinonim) ? 
                    array_map(function($item) {
                        return mb_strtolower(trim($item));
                    }, json_decode($mkDB->sinonim, true)) : 
                    array_map(function($item) {
                        return mb_strtolower(trim($item));
                    }, array_values((array)json_decode($mkDB->sinonim, true)));

                // Hitung Jaccard Similarity
                $jaccardScore = $this->hitungJaccardSimilarity($mappingTranskrip, $mappingMatkul);

                // Hitung Cosine Similarity
                $cosineScore = $this->hitungCosineSimilarity($mappingTranskrip, $mappingMatkul);

                // Calculate final score
                if ($isExactNameMatch) {
                    // If names match exactly, check if mappings also match
                    $mappingMatch = count(array_intersect($mappingTranskrip, $mappingMatkul)) === count($mappingTranskrip) &&
                                  count($mappingTranskrip) === count($mappingMatkul);
                    
                    $finalScore = $mappingMatch ? 1.0 : 0.95; // 100% if both name and mapping match, 95% if only name matches
                } else {
                    // For non-exact matches, use weighted combination
                    $finalScore = ($jaccardScore * 0.3) + ($cosineScore * 0.7);
                }

                if ($finalScore >= 0.7) { // threshold similarity
                    $rekomendasi[] = [
                        'matkul_transkrip' => $mkTranskrip['nama'],
                        'matkul_transkrip_en' => $mkTranskrip['nama_en'],
                        'matkul_target' => $mkDB->nama_matkul,
                        'nilai' => $mkTranskrip['nilai'],
                        'similarity_score' => $finalScore,
                        'jaccard_score' => $jaccardScore,
                        'cosine_score' => $cosineScore,
                        'is_exact_match' => $isExactNameMatch,
                        'mapping_match' => $mappingMatch ?? false
                    ];
                }
            }
        }

        // Sort by similarity score
        usort($rekomendasi, function($a, $b) {
            return $b['similarity_score'] <=> $a['similarity_score'];
        });

        return $rekomendasi;
    }

    private function hitungJaccardSimilarity($set1, $set2)
    {
        // Ensure both sets are arrays and remove duplicates
        $set1 = array_unique(array_filter($set1));
        $set2 = array_unique(array_filter($set2));

        if (empty($set1) || empty($set2)) {
            return 0;
        }

        // Convert all elements to lowercase for comparison
        $set1 = array_map('mb_strtolower', $set1);
        $set2 = array_map('mb_strtolower', $set2);

        $intersection = array_intersect($set1, $set2);
        $union = array_unique(array_merge($set1, $set2));

        return count($intersection) / count($union);
    }

    private function hitungCosineSimilarity($set1, $set2)
    {
        // Ensure both sets are arrays and remove duplicates
        $set1 = array_unique(array_filter($set1));
        $set2 = array_unique(array_filter($set2));

        if (empty($set1) || empty($set2)) {
            return 0;
        }

        // Convert all elements to lowercase for comparison
        $set1 = array_map('mb_strtolower', $set1);
        $set2 = array_map('mb_strtolower', $set2);

        // Create vectors
        $allTerms = array_unique(array_merge($set1, $set2));
        $vector1 = array_fill_keys($allTerms, 0);
        $vector2 = array_fill_keys($allTerms, 0);

        // Calculate term frequencies
        foreach ($set1 as $term) {
            $vector1[$term]++;
        }
        foreach ($set2 as $term) {
            $vector2[$term]++;
        }

        // Calculate dot product and magnitudes
        $dotProduct = 0;
        $magnitude1 = 0;
        $magnitude2 = 0;

        foreach ($allTerms as $term) {
            $dotProduct += $vector1[$term] * $vector2[$term];
            $magnitude1 += $vector1[$term] * $vector1[$term];
            $magnitude2 += $vector2[$term] * $vector2[$term];
        }

        $magnitude1 = sqrt($magnitude1);
        $magnitude2 = sqrt($magnitude2);

        if ($magnitude1 == 0 || $magnitude2 == 0) {
            return 0;
        }

        return $dotProduct / ($magnitude1 * $magnitude2);
    }
    
    public function view_transkrip($filename)
    {
        // Validasi akses
        $user = Auth::user();
        $transkrip = Transkrip::where('file', $filename)
                             ->where('calon_mahasiswa_id', $user->calon_mahasiswa->id)
                             ->firstOrFail();
    
        $path = public_path('Data/Transkrip/' . $filename);
    
        if (!file_exists($path)) {
            abort(404);
        }
    
        $fileExtension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
        if ($fileExtension === 'pdf') {
            // Untuk file PDF, tampilkan menggunakan response()->file()
            return response()->file($path, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'inline; filename="' . $filename . '"'
            ]);
        } else {
            // Untuk file gambar
            return response()->file($path, [
                'Content-Type' => mime_content_type($path)
            ]);
        }
    }
    
    public function delete_transkrip($id)
    {
        $user = auth()->user();
        if ($user->role !== 'pendaftar') {
            abort(403, 'Unauthorized action');
        }
    
        $transkrip = Transkrip::where('id', $id)
                             ->where('calon_mahasiswa_id', $user->calon_mahasiswa->id)
                             ->firstOrFail();
    
        // Hapus file fisik
        $path = public_path('Data/Transkrip/' . $transkrip->file);
        if (file_exists($path)) {
            unlink($path);
        }
    
        // Hapus record dari database
        $transkrip->delete();
    
        return redirect()->route('input-transkrip')
            ->with('success', 'Transkrip berhasil dihapus');
    }

    public function bukti_alih_jenjang_view()
    {
        $user = Auth::user();
        if ($user->role !== 'pendaftar') {
            abort(403, 'Unauthorized action');
        }

        $bukti_list = bukti_alih_jenjang::where('calon_mahasiswa_id', $user->calon_mahasiswa->id)
            ->orderBy('created_at', 'desc')
            ->get();

        return view('User.bukti-alih-jenjang', compact('bukti_list'));
    }

    public function bukti_alih_jenjang_add(Request $request)
    {
        $user = Auth::user();
        if ($user->role !== 'pendaftar') {
            abort(403, 'Unauthorized action');
        }

        $request->validate([
            'jenis_dokumen' => 'required|string|in:Screenshot PDDIKTI,Panduan Kurikulum,Surat ket. pernah kuliah,Lainnya',
            'file' => 'required|mimes:pdf,jpg,jpeg,png|max:2048'
        ]);

        try {
            $file = $request->file('file');
            $filename = time() . '_' . $file->getClientOriginalName();
            
            // Pastikan direktori ada
            $uploadPath = public_path('Data/Bukti_alih_jenjang');
            if (!file_exists($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }
            
            $file->move($uploadPath, $filename);

            bukti_alih_jenjang::create([
                'jenis_dokumen' => $request->jenis_dokumen,
                'calon_mahasiswa_id' => $user->calon_mahasiswa->id,
                'file' => $filename
            ]);

            return redirect()->route('bukti-alih-jenjang-view')
                ->with('success', 'Bukti berhasil ditambahkan');
        } catch (\Exception $e) {
            \Log::error('Error adding bukti: ' . $e->getMessage());
            return redirect()->route('bukti-alih-jenjang-view')
                ->with('error', 'Gagal menambahkan bukti: ' . $e->getMessage());
        }
    }

    public function bukti_alih_jenjang_view_file($filename)
    {
        $user = Auth::user();
        $bukti = bukti_alih_jenjang::where('file', $filename)
            ->where('calon_mahasiswa_id', $user->calon_mahasiswa->id)
            ->firstOrFail();

        $path = public_path('Data/Bukti_alih_jenjang/' . $filename);

        if (!file_exists($path)) {
            abort(404);
        }

        $fileExtension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if ($fileExtension === 'pdf') {
            return response()->file($path, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'inline; filename="' . $filename . '"'
            ]);
        } else {
            return response()->file($path, [
                'Content-Type' => mime_content_type($path)
            ]);
        }
    }

    public function bukti_alih_jenjang_delete($id)
    {
        $user = Auth::user();
        if ($user->role !== 'pendaftar') {
            abort(403, 'Unauthorized action');
        }

        try {
            $bukti = bukti_alih_jenjang::where('nomor_dokumen', $id)
                ->where('calon_mahasiswa_id', $user->calon_mahasiswa->id)
                ->firstOrFail();

            // Hapus file fisik
            $path = public_path('Data/Bukti_alih_jenjang/' . $bukti->file);
            if (file_exists($path)) {
                unlink($path);
            }

            // Hapus record dari database
            $bukti->delete();

            return redirect()->route('bukti-alih-jenjang-view')
                ->with('success', 'Bukti berhasil dihapus');
        } catch (\Exception $e) {
            \Log::error('Error deleting bukti: ' . $e->getMessage());
            return redirect()->route('bukti-alih-jenjang-view')
                ->with('error', 'Gagal menghapus bukti: ' . $e->getMessage());
        }
    }

    public function matkul_self_assessment_view(){
        $user = Auth::user();
        // Ensure the user is a 'pendaftar' and has calon_mahasiswa data
        if ($user->role !== 'pendaftar' || !$user->calon_mahasiswa) {
            abort(403, 'Unauthorized action');
        }

        $calon_mahasiswa = $user->calon_mahasiswa;

        // Get Matkuls for the user's major
        $matkuls = Matkul::where('jurusan_id', $calon_mahasiswa->jurusan_id)->get();

        // Get existing Matkul assessments for the user
        $existingAssessments = MatkulAssessment::where('calon_mahasiswa_id', $calon_mahasiswa->id)
            ->get()
            ->keyBy('matkul_id');

        // Get the user's transcript data
        $transkrip = Transkrip::where('calon_mahasiswa_id', $calon_mahasiswa->id)->first();

        return view('User.matkul-self-assessment', compact('matkuls', 'existingAssessments', 'transkrip'));
    }

    public function store_matkul_self_assessment(Request $request)
    {
        $user = auth()->user();
        // Ensure the user is a 'pendaftar'
        if ($user->role !== 'pendaftar') {
            abort(403, 'Unauthorized action');
        }

        $calon_mahasiswa = $user->calon_mahasiswa;

        $request->validate([
            'assessments' => 'array', // Allows empty array or partial data
            'assessments.*.matkul_id' => 'required|exists:matkul,id',
            'assessments.*.self_assessment_value' => 'nullable|string|in:Sangat Baik,Baik,Tidak Pernah', // Changed to nullable
        ]);

        // Fetch the assigned assessors for this student from the assessments table
        $assignedAssessors = \App\Models\Assessment::where('calon_mahasiswa_id', $calon_mahasiswa->id)->first();

        // Check if the assessments array is present and not empty before looping
        if ($request->has('assessments') && is_array($request->assessments)) {
            foreach ($request->assessments as $assessmentData) {
                // Only process if a self_assessment_value is provided for this matkul
                if (isset($assessmentData['self_assessment_value'])) {
                    MatkulAssessment::updateOrCreate(
                        [
                            'calon_mahasiswa_id' => $calon_mahasiswa->id,
                            'matkul_id' => $assessmentData['matkul_id'],
                        ],
                        [
                            'self_assessment_value' => $assessmentData['self_assessment_value'],
                            // Assign the assessor IDs from the Assessment table
                            'assessor1_id' => $assignedAssessors ? $assignedAssessors->assessor_id_1 : null,
                            'assessor2_id' => $assignedAssessors ? $assignedAssessors->assessor_id_2 : null,
                            'assessor3_id' => $assignedAssessors ? $assignedAssessors->assessor_id_3 : null,
                        ]
                    );
                }
            }
        }

        return redirect()->route('matkul-self-assessment-view')->with('success', 'Self-assessment saved successfully.');
    }

    public function getCpmkByMatkul($matkulId)
    {
        \Log::info('Accessing getCpmkByMatkul', ['matkul_id' => $matkulId]);
        try {
            $cpmks = Cpmk::where('matkul_id', $matkulId)->get();
            \Log::info('CPMK fetched successfully', ['count' => $cpmks->count()]);
            return response()->json($cpmks);
        } catch (\Exception $e) {
            \Log::error('Error in getCpmkByMatkul', ['error' => $e->getMessage(), 'matkul_id' => $matkulId]);
            return response()->json(['message' => 'Error fetching CPMK'], 500);
        }
    }

    public function delete_matkul_transkrip($transkripId, $matkulIndex)
    {
        $user = auth()->user();
        // Ensure the user is a 'pendaftar'
        if ($user->role !== 'pendaftar') {
            abort(403, 'Unauthorized action');
        }

        try {
            $transkrip = Transkrip::where('id', $transkripId)
                               ->where('calon_mahasiswa_id', $user->calon_mahasiswa->id)
                               ->firstOrFail();

            $mataKuliahTranskrip = $transkrip->mata_kuliah_transkrip;

            // Check if the index is valid
            if (!is_array($mataKuliahTranskrip) || !isset($mataKuliahTranskrip[$matkulIndex])) {
                return response()->json(['success' => false, 'message' => 'Invalid Matkul index.'], 400);
            }

            // Remove the item from the array
            array_splice($mataKuliahTranskrip, $matkulIndex, 1);

            // Update the transkrip record
            $transkrip->mata_kuliah_transkrip = $mataKuliahTranskrip;
            $transkrip->save();

            return response()->json(['success' => true, 'message' => 'Mata kuliah berhasil dihapus.']);

        } catch (\Exception $e) {
            \Log::error('Error deleting matkul transkrip: ' . $e->getMessage());
            return response()->json(['success' => false, 'message' => 'Gagal menghapus mata kuliah.'], 500);
        }
    }
}