<?php

namespace App\Http\Controllers;
use App\Models\Jurusan;
use App\Models\Admin;
use App\Models\User;
use App\Models\Calon_mahasiswa;
use App\Models\Assessor;
use App\Models\Cpmk;
use App\Models\Matkul;
use App\Models\Assessment;
use App\Models\Periode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;


class Admin_data_Controller extends Controller
{
    private function getAdminJurusan()
    {
        $admin = Admin::where('user_id', Auth::id())->first();
        return $admin ? $admin->jurusan_id : null;
    }

    public function profile_view_admin(){
        $user = Auth::user();
        $admin = $user->admin ?? new Admin(['user_id' => $user->id]);
        return view('Admin/profile-admin', compact('admin','user'));
    }
    public function profile_edit_admin_view($id){
        $admin = Admin::where('user_id', Auth::id())->findOrFail($id);
        return view('Admin/profile-edit-admin', compact('admin'));
    }
    public function profile_edit_admin(Request $request, $id)
    {
        $request->validate([
            'nama' => 'required|string|max:255',
            'no_hp' => 'required|string|max:255',
            'alamat' => 'required|string|max:255',
            'foto' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $admin = Admin::where('user_id', Auth::id())->findOrFail($id);

        if ($request->hasFile('foto')) {
            $imageName = time().'.'.$request->foto->extension();  
            $request->foto->move(public_path('Data/profile_pict_admin'), $imageName);
            
            if ($admin->foto) {
                $oldImagePath = public_path('Data/profile_pict_admin/' . $admin->foto);
                if (file_exists($oldImagePath)) {
                    unlink($oldImagePath);
                }
            }
    
            $admin->foto = $imageName; 
            $admin->save();
        }

        $admin->update($request->except('foto'));

        return redirect()->route('profile-view-admin');
    }
    public function account_assessor_table(){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $users_assessor = User::where('role', 'assessor')
            ->whereHas('assessor', function($query) use ($jurusan_id) {
                $query->where('jurusan_id', $jurusan_id);
            })->get();

        return view('Admin/account-assessor-table', compact('users_assessor'));
    }
    public function account_assessor_add(){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        return view('Admin/account-assessor-add', compact('jurusan_id'));
    }

    public function account_assessor_add_data(Request $request){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $request->validate([
            'email' => 'required|email|max:255|unique:users',
            'username' => 'required|string|max:255|unique:users',
            'password' => 'required|string|min:6',
            'nama' => 'required|string|max:255',
        ]);

        $user = User::create([
            'email' => $request->email,
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'role' => 'assessor'
        ]);

        Assessor::create([
            'user_id' => $user->id,
            'nama' => $request->nama,
            'jurusan_id' => $jurusan_id,
        ]);

        return redirect()->route('account-assessor-table')->with('success', 'Assessor created successfully!');
    }

    public function account_user_table(){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $active_periodes = Periode::where('is_active', true)->get();
        $users_camaba = [];
        
        if ($active_periodes->isNotEmpty()) {
            $users_camaba = User::where('role', 'pendaftar')
                ->whereHas('calon_mahasiswa', function($query) use ($jurusan_id, $active_periodes) {
                    $query->where('jurusan_id', $jurusan_id)
                          ->whereIn('periode_id', $active_periodes->pluck('id'));
                })->get();
        }

        return view('Admin/account-user-table', compact('users_camaba'));
    }

    public function account_user_add(){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $periodes = Periode::all();
        return view('Admin/account-user-add', compact('jurusan_id', 'periodes'));
    }

    public function account_user_add_data(Request $request){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $request->validate([
            'email' => 'required|email|max:255|unique:users',
            'username' => 'required|string|max:255|unique:users',
            'password' => 'required|string|min:6',
            'nama' => 'required|string|max:255',
            'periode_id' => 'required|exists:periode,id',
        ]);

        $user = User::create([
            'email' => $request->email,
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'role' => 'pendaftar'
        ]);

        Calon_mahasiswa::create([
            'user_id' => $user->id,
            'nama' => $request->nama,
            'jurusan_id' => $jurusan_id,
            'periode_id' => $request->periode_id,
        ]);

        return redirect()->route('account-user-table')->with('success', 'Pendaftar created successfully!');
    }

    public function account_admin_table(){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $users_admin = User::where('role', 'admin')
            ->whereHas('admin', function($query) use ($jurusan_id) {
                $query->where('jurusan_id', $jurusan_id);
            })->get();

        return view('Admin/account-admin-table', compact('users_admin'));
    }

    public function account_admin_add(){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        return view('Admin/account-admin-add', compact('jurusan_id'));
    }

    public function account_admin_add_data(Request $request){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $request->validate([
            'email' => 'required|email|max:255|unique:users',
            'username' => 'required|string|max:255|unique:users',
            'password' => 'required|string|min:6',
            'nama' => 'required|string|max:255',
        ]);

        $user = User::create([
            'email' => $request->email,
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'role' => 'admin'
        ]);

        Admin::create([
            'user_id' => $user->id,
            'nama' => $request->nama,
            'jurusan_id' => $jurusan_id,
        ]);

        return redirect()->route('account-admin-table')->with('success', 'Admin created successfully!');
    }

    public function kelola_assessor_table(){
        return view('Admin/kelola-assessor-table');
    }
    
    // P
    public function kelola_assessor_mahasiswa(Request $request)
    {
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $calon_mahasiswa = Calon_mahasiswa::with([
                'jurusan', 
                'assessment.assessor1', 
                'assessment.assessor2', 
                'assessment.assessor3'
            ])
            ->where('jurusan_id', $jurusan_id)
            ->get();

        $assessor = Assessor::where('jurusan_id', $jurusan_id)->get();

        return view('Admin/kelola-assessor-mahasiswa', compact('calon_mahasiswa', 'assessor'));
    }

    /**
     * Tambah atau perbarui data assessment untuk mahasiswa.
     */
    public function kelola_assessor_mahasiswa_add(Request $request)
    {
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $validated = $request->validate([
            'calon_mahasiswa_id' => 'required|exists:calon_mahasiswa,id',
            'assessor1_id' => 'required|exists:assessor,id',
            'assessor2_id' => 'nullable|exists:assessor,id',
            'assessor3_id' => 'nullable|exists:assessor,id',
        ]);

        $mahasiswa = Calon_mahasiswa::find($validated['calon_mahasiswa_id']);
        if ($mahasiswa->jurusan_id !== $jurusan_id) {
            return back()->withErrors(['message' => 'Unauthorized access to this student.']);
        }

        // Check if assigned assessors are from the same department
        $assessorIds = [
            $validated['assessor1_id'],
            $validated['assessor2_id'],
            $validated['assessor3_id'],
        ];

        foreach ($assessorIds as $assessorId) {
            if ($assessorId) { // Only check if an assessor is assigned
                $assessor = Assessor::find($assessorId);
                if ($assessor->jurusan_id !== $jurusan_id) {
                    return back()->withErrors(['message' => 'Assessor must be from the same department.']);
                }
            }
        }

        // Check for duplicate assessors, ignoring nulls
        $assignedAssessorIds = array_filter($assessorIds); // Remove null values
        if (count($assignedAssessorIds) !== count(array_unique($assignedAssessorIds))) {
            return back()->withErrors(['message' => 'Assessors cannot be the same.']);
        }

        // Use updateOrCreate to save or update the Assessment record
        $assessment = Assessment::updateOrCreate(
            ['calon_mahasiswa_id' => $validated['calon_mahasiswa_id']],
            [
                'jurusan_id' => $jurusan_id,
                'assessor_id_1' => $validated['assessor1_id'],
                'assessor_id_2' => $validated['assessor2_id'],
                'assessor_id_3' => $validated['assessor3_id'],
            ]
        );

        // Now, update the matkul_assessments table for all matkuls of this student's major
        $matkuls = Matkul::where('jurusan_id', $jurusan_id)->get();

        foreach ($matkuls as $matkul) {
            // Find or create the MatkulAssessment record
            $matkulAssessment = \App\Models\MatkulAssessment::firstOrNew([
                'calon_mahasiswa_id' => $validated['calon_mahasiswa_id'],
                'matkul_id' => $matkul->id,
            ]);

            // If it's a new record, set initial values for assessment fields to avoid NOT NULL errors
            if (!$matkulAssessment->exists) {
                $matkulAssessment->self_assessment_value = ''; // Or a suitable default based on schema
                $matkulAssessment->assessor1_assessment = ''; // Or a suitable default
                $matkulAssessment->assessor2_assessment = ''; // Or a suitable default
                $matkulAssessment->assessor3_assessment = ''; // Or a suitable default
            }

            // Update the assessor IDs explicitly
            $matkulAssessment->assessor1_id = $validated['assessor1_id'];
            $matkulAssessment->assessor2_id = $validated['assessor2_id'];
            $matkulAssessment->assessor3_id = $validated['assessor3_id'];

            // Save the MatkulAssessment record. This will create it if it didn't exist or update it.
            $matkulAssessment->save();
        }

        return redirect()->route('kelola-assessor-mahasiswa')->with('success', 'Assessment berhasil dibuat!');
    }
    public function kelola_matkul_table(){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $matkuls = Matkul::where('jurusan_id', $jurusan_id)->get();
        return view('Admin/kelola-matkul-table', compact('matkuls'));
    }
    public function kelola_matkul_add_data(Request $request)
    {
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        try {
            \Log::info('Validating mata kuliah data', [
                'nama_matkul' => $request->nama_matkul,
                'kode_matkul' => $request->kode_matkul,
                'jurusan_id' => $jurusan_id
            ]);

            $validator = \Validator::make($request->all(), [
                'nama_matkul' => [
                    'required',
                    'string',
                    'max:255',
                    function ($attribute, $value, $fail) use ($jurusan_id) {
                        $exists = Matkul::where('jurusan_id', $jurusan_id)
                            ->where('nama_matkul', $value)
                            ->exists();
                        \Log::info('Checking nama_matkul uniqueness', [
                            'value' => $value,
                            'exists' => $exists
                        ]);
                        if ($exists) {
                            $fail('Mata kuliah dengan nama ini sudah ada di jurusan ini.');
                        }
                    }
                ],
                'kode_matkul' => [
                    'nullable',
                    'string',
                    'max:20',
                    function ($attribute, $value, $fail) use ($jurusan_id) {
                        if ($value) {
                            $exists = Matkul::where('jurusan_id', $jurusan_id)
                                ->where('kode_matkul', $value)
                                ->exists();
                            \Log::info('Checking kode_matkul uniqueness', [
                                'value' => $value,
                                'exists' => $exists
                            ]);
                            if ($exists) {
                                $fail('Mata kuliah dengan kode ini sudah ada di jurusan ini.');
                            }
                        }
                    }
                ],
                'sks' => 'nullable|integer|min:1|max:6',
            ]);

            if ($validator->fails()) {
                \Log::info('Validation failed', [
                    'errors' => $validator->errors()->toArray()
                ]);
                return redirect()->route('kelola-matkul-table')
                    ->withErrors($validator)
                    ->withInput();
            }

            $matkulName = $request->nama_matkul;
            $translatedName = $matkulName;

            try {
                $response = Http::withoutVerifying()->get('https://translate.googleapis.com/translate_a/single', [
                    'client' => 'gtx',
                    'sl' => 'auto',
                    'tl' => 'en',
                    'dt' => 't',
                    'q' => $matkulName
                ]);

                if ($response->successful()) {
                    $result = $response->json();
                    if (!empty($result[0][0][0])) {
                        $translatedName = $result[0][0][0];
                        \Log::info("Mata Kuliah: {$matkulName} -> Translated: {$translatedName}");
                    }
                }
            } catch (\Exception $e) {
                \Log::error('Google Translate error: ' . $e->getMessage());
                
                try {
                    $response = Http::withoutVerifying()->post('https://libretranslate.de/translate', [
                        'q' => $matkulName,
                        'source' => 'id',
                        'target' => 'en'
                    ]);

                    if ($response->successful()) {
                        $result = $response->json();
                        $translatedName = $result['translatedText'];
                        \Log::info("Fallback translation: {$matkulName} -> {$translatedName}");
                    }
                } catch (\Exception $e) {
                    \Log::error('Fallback translation error: ' . $e->getMessage());
                }
            }

            $synonyms = [$translatedName];
            
            try {
                $response = Http::get('http://localhost:5000/synonyms', [
                    'word' => strtolower($translatedName)
                ]);

                if ($response->successful()) {
                    $wordnetSynonyms = $response->json();
                    if (!empty($wordnetSynonyms)) {
                        $synonyms = array_merge($synonyms, $wordnetSynonyms);
                    }
                    \Log::info('WordNet synonyms for ' . $translatedName . ': ' . json_encode($wordnetSynonyms));
                }
            } catch (\Exception $e) {
                \Log::error('WordNet service error: ' . $e->getMessage());
                
                $commonSynonyms = [
                    'programming' => ['coding', 'software development', 'computer programming'],
                    'database' => ['db', 'data management', 'data storage', 'dbms'],
                    'network' => ['networking', 'computer network', 'data communication'],
                    'algorithm' => ['algorithmic', 'computational method', 'problem solving'],
                    'security' => ['cybersecurity', 'information security', 'computer security'],
                    'system' => ['information system', 'computing system', 'it system'],
                    'analysis' => ['analytics', 'data analysis', 'system analysis'],
                    'design' => ['system design', 'software design', 'application design'],
                    'web' => ['website', 'web application', 'web development'],
                    'mobile' => ['mobile application', 'mobile development', 'app development'],
                    'artificial intelligence' => ['ai', 'machine learning', 'deep learning'],
                    'operating system' => ['os', 'system software', 'platform'],
                    'discrete' => ['discrete mathematics', 'discrete structure', 'finite mathematics'],
                    'calculus' => ['mathematical analysis', 'integral calculus', 'differential calculus'],
                    'statistics' => ['statistical analysis', 'data statistics', 'probability'],
                ];

                foreach ($commonSynonyms as $key => $values) {
                    if (stripos($translatedName, $key) !== false) {
                        $synonyms = array_merge($synonyms, $values);
                    }
                }
            }

            $synonyms[] = $matkulName;
            $synonyms[] = $translatedName;
            $synonyms = array_unique(array_filter($synonyms));
            
            \Log::info('Final mapping untuk ' . $matkulName . ': ' . json_encode($synonyms));

            $matkul = Matkul::create([
                'nama_matkul' => $matkulName,
                'jurusan_id' => $jurusan_id,
                'sinonim' => json_encode($synonyms),
                'kode_matkul' => $request->kode_matkul,
                'sks' => $request->sks
            ]);

            return redirect()->route('kelola-matkul-table')
                ->with('success', 'Mata Kuliah berhasil ditambahkan dengan ' . count($synonyms) . ' sinonim!');

        } catch (\Exception $e) {
            \Log::error('Error in kelola_matkul_add_data: ' . $e->getMessage());
            return redirect()->route('kelola-matkul-table')
                ->with('error', 'Terjadi kesalahan saat menambahkan mata kuliah. Silakan coba lagi.');
        }
    }

    public function edit_matkul(Request $request, Matkul $matkul)
    {
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        if ($matkul->jurusan_id !== $jurusan_id) {
            return back()->with('error', 'Unauthorized access to this course.');
        }

        $request->validate([
            'nama_matkul' => [
                'required',
                'string',
                'max:255',
                function ($attribute, $value, $fail) use ($jurusan_id, $matkul) {
                    if (Matkul::where('jurusan_id', $jurusan_id)
                        ->where('nama_matkul', $value)
                        ->where('id', '!=', $matkul->id)
                        ->exists()) {
                        $fail('Mata kuliah dengan nama ini sudah ada di jurusan ini.');
                    }
                }
            ],
            'kode_matkul' => [
                'nullable',
                'string',
                'max:20',
                function ($attribute, $value, $fail) use ($jurusan_id, $matkul) {
                    if ($value && Matkul::where('jurusan_id', $jurusan_id)
                        ->where('kode_matkul', $value)
                        ->where('id', '!=', $matkul->id)
                        ->exists()) {
                        $fail('Mata kuliah dengan kode ini sudah ada di jurusan ini.');
                    }
                }
            ],
            'sks' => 'nullable|integer|min:1|max:6',
        ]);

        try {
            $matkulName = $request->nama_matkul;
            $translatedName = $matkulName;

            try {
                $response = Http::withoutVerifying()->get('https://translate.googleapis.com/translate_a/single', [
                    'client' => 'gtx',
                    'sl' => 'auto',
                    'tl' => 'en',
                    'dt' => 't',
                    'q' => $matkulName
                ]);

                if ($response->successful()) {
                    $result = $response->json();
                    if (!empty($result[0][0][0])) {
                        $translatedName = $result[0][0][0];
                        \Log::info("Mata Kuliah: {$matkulName} -> Translated: {$translatedName}");
                    }
                }
            } catch (\Exception $e) {
                \Log::error('Google Translate error: ' . $e->getMessage());
                
                try {
                    $response = Http::withoutVerifying()->post('https://libretranslate.de/translate', [
                        'q' => $matkulName,
                        'source' => 'id',
                        'target' => 'en'
                    ]);

                    if ($response->successful()) {
                        $result = $response->json();
                        $translatedName = $result['translatedText'];
                        \Log::info("Fallback translation: {$matkulName} -> {$translatedName}");
                    }
                } catch (\Exception $e) {
                    \Log::error('Fallback translation error: ' . $e->getMessage());
                }
            }

            $synonyms = [$translatedName];
            
            try {
                $response = Http::get('http://localhost:5000/synonyms', [
                    'word' => strtolower($translatedName)
                ]);

                if ($response->successful()) {
                    $wordnetSynonyms = $response->json();
                    if (!empty($wordnetSynonyms)) {
                        $synonyms = array_merge($synonyms, $wordnetSynonyms);
                    }
                    \Log::info('WordNet synonyms for ' . $translatedName . ': ' . json_encode($wordnetSynonyms));
                } else {
                    \Log::warning('WordNet service returned non-successful status: ' . $response->status());
                }
            } catch (\Exception $e) {
                \Log::error('WordNet service error: ' . $e->getMessage());
                
                // Fallback: Add common synonyms based on keywords
                $commonSynonyms = [
                    'programming' => ['coding', 'software development', 'computer programming'],
                    'database' => ['db', 'data management', 'data storage', 'dbms'],
                    'network' => ['networking', 'computer network', 'data communication'],
                    'algorithm' => ['algorithmic', 'computational method', 'problem solving'],
                    'security' => ['cybersecurity', 'information security', 'computer security'],
                    'system' => ['information system', 'computing system', 'it system'],
                    'analysis' => ['analytics', 'data analysis', 'system analysis'],
                    'design' => ['system design', 'software design', 'application design'],
                    'web' => ['website', 'web application', 'web development'],
                    'mobile' => ['mobile application', 'mobile development', 'app development'],
                    'artificial intelligence' => ['ai', 'machine learning', 'deep learning'],
                    'operating system' => ['os', 'system software', 'platform'],
                    'discrete' => ['discrete mathematics', 'discrete structure', 'finite mathematics'],
                    'calculus' => ['mathematical analysis', 'integral calculus', 'differential calculus'],
                    'statistics' => ['statistical analysis', 'data statistics', 'probability'],
                ];

                foreach ($commonSynonyms as $key => $values) {
                    if (stripos($translatedName, $key) !== false) {
                        $synonyms = array_merge($synonyms, $values);
                    }
                }
            }

            $synonyms[] = $matkulName;
            $synonyms[] = $translatedName;
            $synonyms = array_unique(array_filter($synonyms));
            
            \Log::info('Final mapping for ' . $matkulName . ': ' . json_encode($synonyms));

            $matkul->update([
                'nama_matkul' => $matkulName,
                'kode_matkul' => $request->kode_matkul,
                'sks' => $request->sks,
                'sinonim' => json_encode($synonyms) // Update the synonym field
            ]);

            return redirect()->route('kelola-matkul-table')
                ->with('success', 'Mata Kuliah berhasil diperbarui dengan ' . count($synonyms) . ' sinonim!');
        } catch (\Exception $e) {
            \Log::error('Error in edit_matkul: ' . $e->getMessage());
            return redirect()->route('kelola-matkul-table')
                ->with('error', 'Terjadi kesalahan saat memperbarui mata kuliah. Silakan coba lagi.');
        }
    }

    public function kelola_cpmk_table($matkul_id){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $matkul = Matkul::where('jurusan_id', $jurusan_id)->findOrFail($matkul_id);
        $cpmks = Cpmk::where('matkul_id', $matkul_id)->get();
        return view('Admin/kelola-cpmk-table', compact('matkul', 'cpmks'));
    }
   
    public function create_data_cpmk($matkul_id)
    {
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $matkul = Matkul::where('jurusan_id', $jurusan_id)->findOrFail($matkul_id);
        return view('Admin/kelola-cpmk-table', compact('matkul'));
    }

 
    public function add_data_cpmk(Request $request)
    {
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $request->validate([
            'penjelasan' => 'required|string',
            'matkul_id' => 'required|exists:matkul,id',
            'kode_cpmk' => 'required|string|max:20',
        ]);

        $matkul = Matkul::where('jurusan_id', $jurusan_id)->findOrFail($request->matkul_id);

        Cpmk::create([
            'penjelasan' => $request->penjelasan,
            'matkul_id' => $request->matkul_id,
            'kode_cpmk' => $request->kode_cpmk,
        ]);

        return redirect()->route('kelola-cpmk-table', $request->matkul_id)->with('success', 'CPMK created successfully!');
    }


    public function delete(Cpmk $cpmk)
    {
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $matkul = Matkul::where('jurusan_id', $jurusan_id)->findOrFail($cpmk->matkul_id);
        $cpmk->delete();
        return back()->with('success', 'CPMK deleted successfully!');
    }

    public function delete_cpmk(Cpmk $cpmk)
    {
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $matkul = Matkul::where('jurusan_id', $jurusan_id)->findOrFail($cpmk->matkul_id);
        $cpmk->delete();
        return back()->with('success', 'CPMK deleted successfully!');
    }
    
    public function delete_matkul(Matkul $matkul)
    {
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        if ($matkul->jurusan_id !== $jurusan_id) {
            return back()->with('error', 'Unauthorized access to this course.');
        }

        $matkul->delete();
        return back()->with('success', 'Matkul deleted successfully!');
    }

    public function delete_user(User $user)
    {
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        if ($user->role === 'pendaftar') {
            $calon_mahasiswa = $user->calon_mahasiswa;
            if ($calon_mahasiswa && $calon_mahasiswa->jurusan_id !== $jurusan_id) {
                return back()->with('error', 'Unauthorized access to this user.');
            }
        } elseif ($user->role === 'assessor') {
            $assessor = $user->assessor;
            if ($assessor && $assessor->jurusan_id !== $jurusan_id) {
                return back()->with('error', 'Unauthorized access to this user.');
            }
        }

        $user->delete();
        return back()->with('success', 'User deleted successfully!');
    }

    public function data_user_table(){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $active_periodes = Periode::where('is_active', true)->get();
        $users_camaba = [];
        
        if ($active_periodes->isNotEmpty()) {
            $users_camaba = User::where('role', 'pendaftar')
                ->whereHas('calon_mahasiswa', function($query) use ($jurusan_id, $active_periodes) {
                    $query->where('jurusan_id', $jurusan_id)
                          ->whereIn('periode_id', $active_periodes->pluck('id'));
                })->get();
        }

        return view('Admin/data-user-table', compact('users_camaba'));
    }
    public function data_assessor_table(){
        $jurusan_id = $this->getAdminJurusan();
        if (!$jurusan_id) {
            return redirect()->back()->with('error', 'Jurusan tidak ditemukan');
        }

        $assessor = Assessor::where('jurusan_id', $jurusan_id)->get();
        $users_assessor = User::where('role', 'assessor')
            ->whereHas('assessor', function($query) use ($jurusan_id) {
                $query->where('jurusan_id', $jurusan_id);
            })->get();

        return view('Admin/data-assessor-table', compact('users_assessor', 'assessor'));
    }
}
